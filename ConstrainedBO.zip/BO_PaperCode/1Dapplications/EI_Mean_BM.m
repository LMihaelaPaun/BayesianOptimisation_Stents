%%%%%%%%%%%%%%%%%
%%%%%% Run Bayesian Optimization on a toy problem %%%%%
%%% Mihaela Paun %%%

clear; close all;

addpath(genpath('/./BO_PaperCode'))

% Add path to GPstuff toolbox
% !!!this path only contains the amplitude truncation below 10^5 in fminscg
GPpath = genpath('/./gpstuff-develop'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path

%% SECTION 1: Run the model for a number of parameter values from a space filling design
ex = 3; % example number (1:quadratic, 2:sinusoidal, 3: monotonic)

nd = 1; % no of parameters

nrun = 30;

maxiter = 50; % BO budget (maximum no of function evaluations)

BM_ind = 2; % 1 for Mean-BM acq fct, 2 for EI-BM acq fct
AF_ind = 1; % 1 for EI, 2 for UCB

discreteOptim = 0;

multipleCons = 0; % multiple constraints?

for irun=1:nrun
    
    if ex == 1
        th = -1; % threshold value
        ObjFct = @(x) (x.^2 - 100); % minimise this, should find x=0;
        ConsFct = @(x) (x); % subject to the constrant that x < th
        % lower and upper bounds for the drug mass and stent coating
        l = -10;
        u = 30; 
        
    elseif ex == 2
        
        th = 4; % threshold value
        ObjFct = @(x) sin(x); % minimise this, should find x=0;
        ConsFct = @(x) (x); % subject to the constrant that x < th
        % lower and upper bounds for the drug mass and stent coating
        l = 0;
        u = 2*pi;
        
    else
        
        th = 0; % threshold value
        ObjFct = @(x) -2*x; % minimise this;
        ConsFct = @(x) (x); % subject to the constrant that x < th
        % lower and upper bounds for the drug mass and stent coating
        l = -10;
        u = 10;
        
    end
    
    rng(irun,'twister')
    
    X = lhsdesign(nd*10,nd);
    
    param = l + (u-l) * X(:,1); param = param';
    
    fct_eval = ObjFct(param);
    C_eval = ConsFct(param);
    conSatisf = C_eval<th;
    
    %% SECTION 2: Construct initial GP model out of the simulator callings above
    
    sc = abs(u);
    
    l = l./sc; u = u./sc;
    
    conSatisf = logical(conSatisf);
    
    x_fct = param./sc; y_fct = fct_eval;
    
    x_fct=x_fct'; y_fct=y_fct';
    
    x_cst = param./sc; y_cst = C_eval - th;
    x_cst=x_cst'; y_cst=y_cst';
    
    % Construct regression models
    mean_yfct = mean(y_fct);
    std_yfct = std(y_fct);
    % Scale
    y_fct = (y_fct-mean_yfct)./std_yfct; % mean 0 and std 1 of of y
    
    mean_ycst = mean(y_cst);
    std_ycst = std(y_cst);
    % Scale
    y_cst = (y_cst-mean_ycst)./std_ycst; % mean 0 and std 1 of of y
    
    % initialisations for GP kernel hyperparameters
    X_r = sobolset(nd+2, 'Skip',2e12,'Leap',0.45e15); % draw 10 values
    n_r = size(X_r, 1);
    
    l_r = [0.5 repmat(0.1,1,nd) 10^(-6)];
    u_r = [1.5 ones(1,nd) 1];
    
    % Initialisations for amplitude, lengthscale and likelihood noise for GP
    % regression
    H_r = [];
    for i=1:nd+2
        H_r = [H_r, l_r(i) + (u_r(i)-l_r(i)) * X_r(:,i)];
    end
    
    if BM_ind == 2 % EI-BM
        jitterIndex = 2; % 1:small jitter, 2:large jitter
    else % Mean-BM
        jitterIndex = 1; % 1:small jitter, 2:large jitter
    end
    
    meanf_ind_f = 0;
    
    gp_fct = GPmodel_toy(x_fct, y_fct, [], [], [1 0.1 1e-04], [], [], ...
        meanf_ind_f, jitterIndex);
    
    [w,s] = gp_pak(gp_fct);
    disp(exp(w))
    
    gp_cst = GPmodel_toy(x_cst, y_cst, [], [], [1 0.1 1e-04], [], [], ...
        meanf_ind_f, jitterIndex);
    
    [w,s] = gp_pak(gp_cst);
    disp(exp(w))
    
    %Make predictions using gp_norm_areaRs2
    E_fct = gp_pred(gp_fct, x_fct, y_fct, x_fct);
    
    figure(1); clf(1);
    plot(E_fct,E_fct,'-r','linewidth',2);hold on;
    plot(E_fct, y_fct, 'ob','markersize',6,'markerfacecolor',[0 0 1]);
    set(gca,'fontsize',20);grid on;
    xlabel('Train data'); ylabel('Predictions')
    
    %Make predictions using gp_norm_areaRs2
    E_cst = gp_pred(gp_cst, x_cst, y_cst, x_cst);
    
    figure(2); clf(2);
    plot(E_cst,E_cst,'-r','linewidth',2);hold on;
    plot(E_cst, y_cst, 'ob','markersize',6,'markerfacecolor',[0 0 1]);
    set(gca,'fontsize',20);grid on;
    xlabel('Train data'); ylabel('Predictions')
    
    %% SECTION 3: Carry out BO
    
    i1 = 0; % no of successful BO iterations
    improv = inf;   % improvement between two successive query points
    
    % Set the options for optimizer of the acquisition function
        
    opts = optimoptions(@fmincon,'Algorithm','sqp');
    
    globalOptimaY = inf * ones(maxiter,1); % stores all the global optima y (obj fct) points
    globalOptimaX = inf * ones(maxiter,1); % stores all the global optima x (param) points
    
    count = 0; % total no of iterations (includes those that progress or not the obj fct)
    
    globalOptimaYfct_min = inf;
    
    while count < maxiter %&& improv>1e-6
        
        count = count + 1;
        
        fmin = min(y_fct(y_cst.*std_ycst+mean_ycst<=0));
        
        % optimize acquisition function
        
        fh_af = @(x_new) barrierMethodAcqF(x_new, gp_fct, x_fct, y_fct, mean_yfct, std_yfct, ...
            gp_cst, x_cst, y_cst, mean_ycst, std_ycst, fmin, BM_ind, AF_ind, [], [], multipleCons);
        

        if discreteOptim==1
            Xstar = lhsdesign(10^3,1);
            xstar=l + (u-l) .* Xstar;
            AFstar = fh_af(xstar);
            xstart = xstar(AFstar==min(AFstar));
            
            bestX = xstart;
            
        else
            
            Xo = lhsdesign(1,nd);
            xstart = NaN(size(Xo,1),nd);
            for j=1:nd
                xstart(:,j) = l(j) + (u(j)-l(j)) * Xo(:,j); % starting values for the BO algorithm
            end
            
            problem = createOptimProblem('fmincon','objective',...
                fh_af,'x0',xstart,'lb',l,'ub',u,'options',opts);
            
            gs = GlobalSearch('NumTrialPoints',10^3); % !!!! 10^4 might act out, might need to go down to 10^3
            
            [bestX,bestAF] = run(gs,problem);
            
        end

        bX = bestX.*sc;
        
        % calculate the obj fct value at query point by evaluating simulator
        bestObjF= ObjFct(bX);
        bestCst = ConsFct(bX)-th;
        conS = bestCst<10^(-4);
        
        if conS == 1 && bestObjF < globalOptimaYfct_min
            % the minimum so far
            globalOptimaYfct_min = bestObjF;
            globalOptimaXfct_min = bX;
        end
        
        % put new sample point to the list of evaluation points for norm areaRs2
        x_fct(end+1,:) = bestX;
        y_fct = y_fct.*std_yfct+mean_yfct; % un-scale
        y_fct(end+1) = bestObjF; % on original scale
        mean_yfct = mean(y_fct); std_yfct = std(y_fct); % new mean and std
        
        y_fct = (y_fct-mean_yfct)./std_yfct; % scale back
        
        if conS == 1 % successful simulation
            
            globalOptimaY(count) = bestObjF; % y on original scale it's okay
            globalOptimaX(count) = bX; % x on original scale
            
            disp('successful')
            
            if i1>=1
                improv = abs(globalOptimaY(end)-globalOptimaY(end-1));
            end
            
            i1 = i1 + 1;
            
        else
            disp('unsuccessful')
            
            i1 = i1;
            
        end
        
        % put new sample point to the list of evaluation points for DCmax-th
        
        x_cst(end+1,:) = bestX;
        y_cst = y_cst.*std_ycst+mean_ycst; % un-scale
        y_cst(end+1) = bestCst;
        mean_ycst = mean(y_cst); std_ycst = std(y_cst); % new mean and std
        
        y_cst = (y_cst-mean_ycst)./std_ycst; % scale back
        
        
        % update GPs
        gp_fct = gp_optim(gp_fct,x_fct,y_fct);
        gp_cst = gp_optim(gp_cst,x_cst,y_cst);
        
        if discreteOptim==1
            
            if BM_ind == 1
                if ex == 1
                    save(sprintf('/./PaperResults/ToyProblems/QuadraticExample/Mean_BM_BO_discreteOptim_run %d.mat', irun))
                elseif ex == 2
                    save(sprintf('/./PaperResults/ToyProblems/SinusoidalExample/Mean_BM_BO_discreteOptim_run %d.mat', irun))
                else
                    save(sprintf('/./PaperResults/ToyProblems/MonotonicExample/Mean_BM_BO_discreteOptim_run %d.mat', irun))
                end
                
            else %BM_ind=2
                
                if ex == 1
                    save(sprintf('/./PaperResults/ToyProblems/QuadraticExample/EI_BM_BO_discreteOptim_run %d.mat', irun))
                elseif ex == 2
                    save(sprintf('/./PaperResults/ToyProblems/SinusoidalExample/EI_BM_BO_discreteOptim_run %d.mat', irun))
                else
                    save(sprintf('/./PaperResults/ToyProblems/MonotonicExample/EI_BM_BO_discreteOptim_run %d.mat', irun))
                end
                
            end
            
        else
            
            if BM_ind == 1
                if ex == 1
                    save(sprintf('/./PaperResults/ToyProblems/QuadraticExample/Mean_BM_BO_run %d.mat', irun))
                elseif ex == 2
                    save(sprintf('/./PaperResults/ToyProblems/SinusoidalExample/Mean_BM_BO_run %d.mat', irun))
                else
                    save(sprintf('/./PaperResults/ToyProblems/MonotonicExample/Mean_BM_BO_run %d.mat', irun))
                end
                
            else %BM_ind=2
                
                if ex == 1
                    save(sprintf('/./PaperResults/ToyProblems/QuadraticExample/EI_BM_BO_run %d.mat', irun))
                elseif ex == 2
                    save(sprintf('/./PaperResults/ToyProblems/SinusoidalExample/EI_BM_BO_run %d.mat', irun))
                else
                    save(sprintf('/./PaperResults/ToyProblems/MonotonicExample/EI_BM_BO_run %d.mat', irun))
                end
                
            end
            
        end
    end

end

exit;