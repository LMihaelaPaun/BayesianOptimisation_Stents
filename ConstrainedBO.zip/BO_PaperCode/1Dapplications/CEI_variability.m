%%%%%%%%%%%%%%%%%
%%%%%% Run Bayesian Optimization on a toy problem %%%%%
% This script investigates the effect of different GP settings
%%% Mihaela Paun %%%

clear; close all;

addpath(genpath('/./BO_PaperCode'))

% Add path to GPstuff toolbox
% !!!this path only contains the amplitude truncation below 10^5 in fminscg
GPpath = genpath('/./gpstuff-develop'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path

%% SECTION 1: Run the model for a number of parameter values from a space filling design
ex = 3;

nd = 1; % no of parameters

nrun = 10;

maxiter = 50; % BO budget (maximum no of function evaluations)

discrete_optim = 0;

multipleCons = 0; % multiple constraints?

% delete(gcp('nocreate'))
% parpool('local', nrun)

for testIndex = 1:13
    
    try
        
        parfor irun=1:nrun
            
            if ex == 1
                th = -1; % threshold value
                ObjFct = @(x) (x.^2 - 100); % minimise this, should find x=0;
                ConsFct = @(x) (x); % subject to the constrant that x < th
                % lower and upper bounds for the drug mass and stent coating
                l = -10;
                u = 30;
                
            elseif ex == 2
                
                th = 4; % threshold value
                ObjFct = @(x) sin(x); % minimise this, should find x=0;
                ConsFct = @(x) (x); % subject to the constrant that x < th
                % lower and upper bounds for the drug mass and stent coating
                l = 0;
                u = 2*pi;
                
            else
                
                th = 0; % threshold value
                ObjFct = @(x) -2*x; % minimise this;
                ConsFct = @(x) (x); % subject to the constrant that x < th
                % lower and upper bounds for the drug mass and stent coating
                l = -10;
                u = 10;
                
            end
            
            rng(irun,'twister')
            
            X = lhsdesign(nd*10,nd);
            
            param = l + (u-l) * X(:,1); param = param';
            
            fct_eval = ObjFct(param);
            C_eval = ConsFct(param);
            conSatisf = C_eval<th;
            
            %% SECTION 2: Construct initial GP model out of the simulator callings above
            
            sc = abs(u);
            
            l = l./sc; u = u./sc;
            
            conSatisf = logical(conSatisf);
            
            x_regr = param./sc; y_regr = fct_eval;
            
            x_class = param./sc; y_class = 2.*conSatisf-1;
            
            %%%
            
            mean_y = mean(y_regr);
            std_y = std(y_regr);
            
            % Scale y_regr
            y_regr = (y_regr-mean_y)./std_y; % mean 0 and std 1 of of y
            
            x_regr = x_regr'; x_class = x_class';
            y_regr = y_regr'; y_class = y_class';
            
            % Build GP models (regression emulator for normalised area above Rs2)
            % and classifier for upper constraint on DC max value
            
            X_r = sobolset(nd+2, 'Skip',2e12,'Leap',0.45e15); % draw 10 values
            n_r = size(X_r, 1);
            
            l_r = [0.5 repmat(0.1,1,nd) 10^(-6)];
            u_r = [1.5 ones(1,nd) 1];
            
            % Initialisations for amplitude, lengthscale and likelihood noise for GP
            % regression
            H_r = [];
            for i=1:nd+2
                H_r = [H_r, l_r(i) + (u_r(i)-l_r(i)) * X_r(:,i)];
            end
            
            % Initialisations for amplitude and lengthscale for GP classification
            X_c = sobolset(nd+1, 'Skip',4e8,'Leap',0.45e15); % draw 21 values
            n_c = size(X_c, 1);
            
            l_c = [0.5 repmat(0.1,1,nd)];
            u_c = [1.5 ones(1,nd)];
            
            H_c = [];
            for i=1:nd+1
                H_c = [H_c, l_c(i) + (u_c(i)-l_c(i)) * X_c(:,i)];
            end
            
            meanf_ind_f=0; meanf_ind_c=2; % quadratic mean
            
            if testIndex == 1
                [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                    GPmodel_toy_CEItest1(x_regr, y_regr, x_class, y_class, H_r, H_c(1,:), meanf_ind_c,meanf_ind_f);
            elseif testIndex == 2
                [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                    GPmodel_toy_CEItest2(x_regr, y_regr, x_class, y_class, H_r, H_c(1,:), meanf_ind_c,meanf_ind_f);
            elseif testIndex == 3
                [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                    GPmodel_toy_CEItest3(x_regr, y_regr, x_class, y_class, H_r, H_c(1,:), meanf_ind_c,meanf_ind_f);
            elseif testIndex == 4
                [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                    GPmodel_toy_CEItest4(x_regr, y_regr, x_class, y_class, H_r, H_c(1,:), meanf_ind_c,meanf_ind_f);
            elseif testIndex == 5
                [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                    GPmodel_toy_CEItest5(x_regr, y_regr, x_class, y_class, H_r, H_c(1,:), meanf_ind_c,meanf_ind_f);
            elseif testIndex == 6
                [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                    GPmodel_toy_CEItest6(x_regr, y_regr, x_class, y_class, H_r, H_c(1,:), meanf_ind_c,meanf_ind_f);
            elseif testIndex == 7
                [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                    GPmodel_toy_CEItest7(x_regr, y_regr, x_class, y_class, H_r, H_c(1,:), meanf_ind_c,meanf_ind_f);
            elseif testIndex == 8
                [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                    GPmodel_toy_CEItest8(x_regr, y_regr, x_class, y_class, H_r, H_c(1,:), meanf_ind_c,meanf_ind_f);
            elseif testIndex == 9
                [gp_regr, nlml_regr, gp_class, nlml_class] = ...
                    GPmodel_toy_CEItest9(x_regr, y_regr, x_class, y_class, H_r, H_c(1,:), meanf_ind_c,meanf_ind_f);
            elseif testIndex == 10
                [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                    GPmodel_toy_CEItest10(x_regr, y_regr, x_class, y_class, H_r, H_c(1,:), meanf_ind_c,meanf_ind_f);
            elseif testIndex == 11
                [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                    GPmodel_toy_CEItest11(x_regr, y_regr, x_class, y_class, H_r, H_c(1,:), meanf_ind_c,meanf_ind_f);
            elseif testIndex == 12
                [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                    GPmodel_toy_CEItest12(x_regr, y_regr, x_class, y_class, H_r, H_c(1,:), meanf_ind_c,meanf_ind_f);
            else
                [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                    GPmodel_toy_CEItest13(x_regr, y_regr, x_class, y_class, H_r, H_c(1,:), meanf_ind_c,meanf_ind_f);
            end
            
            %% SECTION 3: Carry out BO
            
            % Set the options for optimizer of the acquisition function
            
            opts = optimoptions(@fmincon,'Algorithm','sqp');
            
            i1 = 0; % no of BO iterations -- no of iterations when constraint satisfied
            
            globalOptimaY = inf * ones(maxiter,1); % stores all the global optima y (obj fct) points
            globalOptimaX = inf * ones(maxiter,nd); % stores all the global optima x (param) points
            
            count = 0; % total no of iterations (includes those that progress or not the obj fct)
            
            globalOptimaYfct_min = inf;
            
            tst = 1; % which test statitic we optimise in expectedImprovement_hcw_entropy
            alp1=1; alp2=1; w=NaN; % parameters for the test statistic
            
            while count < maxiter %&& improv>1e-6
                
                count = count + 1;
                
                [K, C] = gp_trcov(gp_regr,x_regr);
                invC = inv(C);
                a = C\y_regr;
                fmin = min(y_regr(y_class==1));
                
                fh_af = @(x_new) expectedimprovement_hcw_entropy(x_new, gp_regr, x_regr, a, invC,...
                    fmin, gp_class, x_class, y_class, mean_y, std_y, tst, alp1, alp2, w, multipleCons);
                
                if discrete_optim==1
                    Xstar = lhsdesign(10^3,1);
                    xstar=l + (u-l) .* Xstar;
                    AFstar = fh_af(xstar);
                    xstart = xstar(AFstar==min(AFstar));
                    
                    bestX = xstart;
                    
                else
                    
                    Xo = lhsdesign(1,nd);
                    xstart = NaN(size(Xo,1),nd);
                    for j=1:nd
                        xstart(:,j) = l(j) + (u(j)-l(j)) * Xo(:,j); % starting values for the BO algorithm
                    end
                    
                    problem = createOptimProblem('fmincon','objective',...
                        fh_af,'x0',xstart,'lb',l,'ub',u,'options',opts);
                    
                    gs = GlobalSearch('NumTrialPoints',10^3);
                    [bestX,bestAF] = run(gs,problem);
                    
                end
                
                bX = bestX.*sc;
                
                bestObjF= ObjFct(bX);
                bestCst = ConsFct(bX)-th;
                conS = bestCst<10^(-4);
                
                if conS == 1 && bestObjF < globalOptimaYfct_min
                    % the minimum so far
                    globalOptimaYfct_min = bestObjF;
                    globalOptimaXfct_min = bX;
                end
                
                % put new sample point to the list of evaluation regression points
                x_regr(end+1) = bestX;
                y_regr = y_regr.*std_y+mean_y; % un-scale
                y_regr(end+1) = bestObjF; % on original scale
                mean_y = mean(y_regr); std_y = std(y_regr); % new mean and std
                
                y_regr = (y_regr-mean_y)./std_y; % scale back
                
                if conS == 1 % successful simulation
                    
                    globalOptimaY(count) = bestObjF; % y on original scale it's okay
                    globalOptimaX(count) = bX; % x on original scale
                    
                    disp('successful')
                    
                    if i1>=1
                        improv = abs(globalOptimaY(end)-globalOptimaY(end-1));
                    end
                    
                    i1 = i1 + 1;
                    
                else
                    disp('unsuccessful')
                    
                    i1 = i1;
                    
                end
                
                % put new sample point to the list of evaluation classification points
                x_class(end+1) = bestX; y_class(end+1) = 2.*conS-1;
                
                try
                    
                    gp_regr = gp_optim(gp_regr,x_regr,y_regr);
                    gp_class = gp_optim(gp_class,x_class,y_class);
                    
                catch
                    
                    if testIndex == 1
                        [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                            GPmodel_toy_CEItest1(x_regr, y_regr, x_class, y_class, H_r(1,:), H_c(1,:), meanf_ind_c,meanf_ind_f);
                    elseif testIndex == 2
                        [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                            GPmodel_toy_CEItest2(x_regr, y_regr, x_class, y_class, H_r(1,:), H_c(1,:), meanf_ind_c,meanf_ind_f);
                    elseif testIndex == 3
                        [gp_regr, nlml_regr, gp_class, nlml_class] = ...
                            GPmodel_toy_CEItest3(x_regr, y_regr, x_class, y_class, H_r(1,:), H_c(1,:), meanf_ind_c,meanf_ind_f);
                    elseif testIndex == 4
                        [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                            GPmodel_toy_CEItest4(x_regr, y_regr, x_class, y_class, H_r(1,:), H_c(1,:), meanf_ind_c,meanf_ind_f);
                    elseif testIndex == 5
                        [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                            GPmodel_toy_CEItest5(x_regr, y_regr, x_class, y_class, H_r(1,:), H_c(1,:), meanf_ind_c,meanf_ind_f);
                    elseif testIndex == 6
                        [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                            GPmodel_toy_CEItest6(x_regr, y_regr, x_class, y_class, H_r(1,:), H_c(1,:), meanf_ind_c,meanf_ind_f);
                    elseif testIndex == 7
                        [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                            GPmodel_toy_CEItest7(x_regr, y_regr, x_class, y_class, H_r(1,:), H_c(1,:), meanf_ind_c,meanf_ind_f);
                    elseif testIndex == 8
                        [gp_regr, nlml_regr, gp_class, ~] = ... 
                            GPmodel_toy_CEItest8(x_regr, y_regr, x_class, y_class, H_r(1,:), H_c(1,:), meanf_ind_c,meanf_ind_f);
                    elseif testIndex == 9
                        [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                            GPmodel_toy_CEItest9(x_regr, y_regr, x_class, y_class, H_r(1,:), H_c(1,:), meanf_ind_c,meanf_ind_f);
                    elseif testIndex == 10
                        [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                            GPmodel_toy_CEItest10(x_regr, y_regr, x_class, y_class, H_r(1,:), H_c(1,:), meanf_ind_c,meanf_ind_f);
                    elseif testIndex == 11
                        [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                            GPmodel_toy_CEItest11(x_regr, y_regr, x_class, y_class, H_r(1,:), H_c(1,:), meanf_ind_c,meanf_ind_f);
                    elseif testIndex == 12
                        [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                            GPmodel_toy_CEItest12(x_regr, y_regr, x_class, y_class, H_r(1,:), H_c(1,:), meanf_ind_c,meanf_ind_f);
                    else
                        [gp_regr, nlml_regr, gp_class, nlml_class] = ... 
                            GPmodel_toy_CEItest13(x_regr, y_regr, x_class, y_class, H_r(1,:), H_c(1,:), meanf_ind_c,meanf_ind_f);
                        
                    end
                    
                end
                
                if ex==2
                    parsave(sprintf('/./PaperResults/ToyProblems/SinusoidalExample/CEItest%d_BO_run %d.mat', testIndex, irun), globalOptimaX, globalOptimaY, i1, count)
                elseif ex==3
                    parsave(sprintf('/./PaperResults/ToyProblems/MonotonicExample/CEItest%d_BO_run %d.mat', testIndex, irun), globalOptimaX, globalOptimaY, i1, count)
                end
                
            end
            
        end
        
    catch
        
        disp 'no luck'
        
    end
    
end %testIndex

exit;