clear; close all

%system('killall -9 comsollauncher java'); % kill previous running Comsol server instances to prevent port assignment problems

% start the comsol server
addpath('/maths/comsol60/multiphysics/mli')
comsolPort = 2050; % set unique port
system( ['/maths/comsol60/multiphysics/bin/comsol -np 1 server -port ',num2str(comsolPort), ' &'] ); % start a Comsol server
pause( 30 ) % give Comsol server time to start up
% instead of the above, I should try the ID file writing
mphstart(comsolPort); % comsolPort is the port number

addpath(genpath('/./BO_PaperCode'))

% Add path to GPstuff toolbox
% !!!this path only contains the amplitude truncation below 10^5 in fminscg
GPpath = genpath('/./gpstuff-develop'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path

nrun = 10;

maxiter = 50; % BO budget (maximum no of function evaluations)

multipleCons = 0; % multiple constraints?

BM_ind = 2; % 1 for Mean-BM acq fct, 2 for EI-BM acq fct
AF_ind = 2; % 1 for EI, 2 for UCB

for irun=1:nrun
    
    %% SECTION 1: load pre-run initial design
    load(sprintf('/./PaperResults/Stents/3D/InitialDesign_run %d.mat', irun))
    
    sc = abs(u);
    
    l = l./sc; u = u./sc;
    
    % construct one gp regression model for blackbox fct f(theta) = norm_areaRs2
    % and another gp regression model for constraint function c(theta) = DCmax - th
    
    conSatisf = logical(conSatisf);
    
    x_fct = param./sc; y_fct = norm_areaRs2;
    
    x_cst = param./sc; y_cst = DCmax - th;
    
    % Construct regression models
    mean_yfct = mean(y_fct);
    std_yfct = std(y_fct);
    % Scale
    y_fct = (y_fct-mean_yfct)./std_yfct; % mean 0 and std 1 of of y
    
    mean_ycst = mean(y_cst);
    std_ycst = std(y_cst);
    % Scale
    y_cst = (y_cst-mean_ycst)./std_ycst; % mean 0 and std 1 of of y
    
    % initialisations for GP kernel hyperparameters
    X_r = sobolset(nd+2, 'Skip',2e12,'Leap',0.45e15); % draw 10 values
    n_r = size(X_r, 1);
    
    l_r = [0.5 repmat(0.1,1,nd) 10^(-6)];
    u_r = [1.5 ones(1,nd) 1];
    
    % Initialisations for amplitude, lengthscale and likelihood noise for GP
    % regression
    H_r = [];
    for i=1:nd+2
        H_r = [H_r, l_r(i) + (u_r(i)-l_r(i)) * X_r(:,i)];
    end
    
    jitterIndex = 1; % 1:small jitter, 2:large jitter
    
    meanf_ind_f=0;
    
    gp_fct = GPmodel_toy(x_fct, y_fct, [], [], [1 0.1 1e-04], [], [], ...
        meanf_ind_f, jitterIndex);
    
    [w,s] = gp_pak(gp_fct);
    disp(exp(w))
    
    gp_cst = GPmodel_toy(x_cst, y_cst, [], [], [1 0.1 1e-04], [], [], ...
        meanf_ind_f, jitterIndex);
    
    [w,s] = gp_pak(gp_cst);
    disp(exp(w))
    
    
    %% SECTION 3: Carry out BO
    
    i1 = 0; % no of successful BO iterations
    
    count = 0; % total no of iterations (includes those that progress or not the obj fct)
    
    % Set the options for optimizer of the acquisition function
    
    opts = optimoptions(@fmincon,'Algorithm','sqp');
    
    globalOptimaY = inf * ones(maxiter,1); % stores all the global optima y (obj fct) points
    globalOptimaX = inf * ones(maxiter,nd); % stores all the global optima x (param) points
    
    DCmax_BO = NaN(maxiter,1); % vector with all the DCmax values from BO
    norm_aRs2 = NaN(maxiter,1); % vector with all norm areaRs2 values from BO
    
    globalOptimaYfct_min = inf;
    
    delta = 0.1; % needed for UCB calculation
    
    minUCB_idx = 1; % needed for UCB calculation (minimise fx)
    
    while count < maxiter
        
        count = count + 1;
        
        betaC = 2*log((pi^2*(count+1)^(nd/2+2))/(3*delta));
        
        % update GPs
        gp_fct = gp_optim(gp_fct,x_fct,y_fct);
        gp_cst = gp_optim(gp_cst,x_cst,y_cst);
        
        % optimize acquisition function
        
        fh_af = @(x_new) barrierMethodAcqF(x_new, gp_fct, x_fct, y_fct, mean_yfct, std_yfct, ...
            gp_cst, x_cst, y_cst, mean_ycst, std_ycst, [], BM_ind, AF_ind, minUCB_idx, betaC, multipleCons);
        
        Xo = lhsdesign(1,nd);
        xstart = NaN(size(Xo,1),nd);
        for j=1:nd
            xstart(:,j) = l(j) + (u(j)-l(j)) * Xo(:,j); % starting values for the BO algorithm
        end
        
        problem = createOptimProblem('fmincon','objective',...
            fh_af,'x0',xstart,'lb',l,'ub',u,'options',opts);
        
        gs = GlobalSearch('NumTrialPoints',10^3); % !!!! 10^4 might act out, might need to go down to 10^3
        [bestX,bestAF] = run(gs,problem);
        
        bX = bestX.*sc;
        
        % calculate the obj fct value at query point by evaluating simulator
        [norm_aRs2(count), DCmax_BO(count), conS] = Run_Comsol_Simulator(bX,th);
        
        if conS==1 && norm_aRs2(count) < globalOptimaYfct_min
            % the minimum so far
            globalOptimaYfct_min = norm_aRs2(count);
            globalOptimaXfct_min = bX;
            
        end
        
        if isfinite(norm_aRs2(count))
            
            % put new sample point to the list of evaluation points for norm areaRs2
            x_fct(end+1,:) = bestX;
            y_fct = y_fct.*std_yfct+mean_yfct; % un-scale
            y_fct(end+1) = norm_aRs2(count); % on original scale
            mean_yfct = mean(y_fct); std_yfct = std(y_fct); % new mean and std
            
            y_fct = (y_fct-mean_yfct)./std_yfct; % scale back
            
            if conS == 1 % successful simulation
                
                globalOptimaY(count) = norm_aRs2(count); % y on original scale it's okay
                globalOptimaX(count,:) = bX; % x on original scale
                
                disp('successful')
                
                i1 = i1 + 1;
                
            else
                disp('unsuccessful')
                
                i1 = i1;
                
            end
            
            % put new sample point to the list of evaluation points for DCmax-th
            
            x_cst(end+1,:) = bestX;
            y_cst = y_cst.*std_ycst+mean_ycst; % un-scale
            ct = DCmax_BO(count)-th;
            y_cst(end+1) = ct;
            mean_ycst = mean(y_cst); std_ycst = std(y_cst); % new mean and std
            
            y_cst = (y_cst-mean_ycst)./std_ycst; % scale back
            
        end
        
        save(sprintf('/./PaperResults/Stents/3D/Stents_UCB_BM_BO_3D_run %d.mat',irun))
        
    end
    
end

exit;