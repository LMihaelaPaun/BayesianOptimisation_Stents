%%%%%%%%%%%%%%%%%
%%%%%% Run Bayesian Optimization on the stents problem %%%%%
%%% Mihaela Paun %%%

clear; close all;

%system('killall -9 comsollauncher java'); % kill previous running Comsol server instances to prevent port assignment problems

addpath(genpath('/./BO_PaperCode'))

% Add path to GPstuff toolbox
% !!!this path only contains the amplitude truncation below 10^5 in fminscg
GPpath = genpath('/./gpstuff-develop'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path

%% SECTION 1: Run the model for a number of parameter values from a space filling design

th = 150; % threshold value for the drug content DC value
% lower and upper bounds for the drug mass, stent coating and diffusion
% coefficient
%         l = [5, 1e-18, 1];
%         u = [25, 1e-13, 10];
l = [5, 1e-18, 7];
u = [10, 1e-16, 10];

nd = 3; % no of parameters

nrun = 10;

nr = 12;

delete(gcp('nocreate'))

pool = parpool('local',nr); % open local pool with nr Workers

% start the comsol servers
parfor j=1:nr
    addpath('/maths/comsol60/multiphysics/mli')
    comsolPort = 2035+j; % set unique port
    system( ['/maths/comsol60/multiphysics/bin/comsol -np 1 server -port ',num2str(comsolPort), ' &'] ); % start a Comsol server
    pause( 30 ) % give Comsol server time to start up
    % instead of the above, I should try the ID file writing
    mphstart(comsolPort); % comsolPort is the port number
end

for irun=1:nrun
    
    rng(irun,'twister')
    
    X = lhsdesign(nd*10,nd);
    
    param = l + (u-l) .* X;
    
    %param = [m_drug_values, D_coat_values, h_coat_values];
    
    success = NaN(size(X,1),1); % records whether we have a simulation that runs successfully,
    % i.e. no convergence issues, no Matlab getting stuck
    norm_areaRs2 = NaN(size(X,1),1); % stores objective function values
    DCmax = NaN(size(X,1),1); % stores the max drug content value
    conSatisf = NaN(size(X,1),1); % indicator vector for whether constraint is satisfied
    
    parfor i=1:size(X,1)
        
        % Get the objective function: normalised area above the RS2 curve --> TO MINIMISE
        % and the maximum drug content value for constraint optimisation (this will need to be below a threshold of 150)
        % and check if the simulation was successful
        [norm_areaRs2(i), DCmax(i), conSatisf(i), success(i)] = Run_Comsol_Simulator(param(i,:), th);
        
        
    end
    
    save(sprintf('/./PaperResults/Stents/3D/InitialDesign_run %d.mat', irun))
    
end

exit;