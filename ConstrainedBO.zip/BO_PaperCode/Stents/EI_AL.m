
clear; close all

%system('killall -9 comsollauncher java'); % kill previous running Comsol server instances to prevent port assignment problems

% start the comsol server
addpath('/maths/comsol60/multiphysics/mli')
comsolPort = 2045; % set unique port
system( ['/maths/comsol60/multiphysics/bin/comsol -np 1 server -port ',num2str(comsolPort), ' &'] ); % start a Comsol server
pause( 30 ) % give Comsol server time to start up
% instead of the above, I should try the ID file writing
mphstart(comsolPort); % comsolPort is the port number

addpath(genpath('/./BO_PaperCode'))

% Add path to GPstuff toolbox
% !!!this path only contains the amplitude truncation below 10^5 in fminscg
GPpath = genpath('/./gpstuff-develop'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path

nrun = 10;

maxiter = 50; % BO budget (maximum no of function evaluations)

multipleCons = 0; % multiple constraints?

for irun=1:nrun
    
    %% SECTION 1: load pre-run initial design
    load(sprintf('/./PaperResults/Stents/3D/InitialDesign_run %d.mat', irun))
    
    sc = abs(u);
    
    l = l./sc; u = u./sc;
    
    % construct one gp regression model for blackbox fct f(theta) = norm_areaRs2
    % and another gp regression model for constraint function c(theta) = DCmax - th
    
    conSatisf = logical(conSatisf);
    
    x_fct = param./sc; y_fct = norm_areaRs2;
    
    x_cst = param./sc; y_cst = DCmax - th;
    
    % Construct regression models
    mean_yfct = mean(y_fct);
    std_yfct = std(y_fct);
    % Scale
    y_fct = (y_fct-mean_yfct)./std_yfct; % mean 0 and std 1 of of y
    
    mean_ycst = mean(y_cst);
    std_ycst = std(y_cst);
    % Scale
    y_cst = (y_cst-mean_ycst)./std_ycst; % mean 0 and std 1 of of y
    
    % initialisations for GP kernel hyperparameters
    X_r = sobolset(nd+2, 'Skip',2e12,'Leap',0.45e15); % draw 10 values
    n_r = size(X_r, 1);
    
    l_r = [0.5 repmat(0.1,1,nd) 10^(-6)];
    u_r = [1.5 ones(1,nd) 1];
    
    % Initialisations for amplitude, lengthscale and likelihood noise for GP
    % regression
    H_r = [];
    for i=1:nd+2
        H_r = [H_r, l_r(i) + (u_r(i)-l_r(i)) * X_r(:,i)];
    end
    
    jitterIndex = 1; % 1:small jitter, 2:large jitter
    
    meanf_ind_f=0;
    
    gp_fct = GPmodel_toy(x_fct, y_fct, [], [], [1 0.1 1e-04], [], [], ...
        meanf_ind_f, jitterIndex);
    
    [w,s] = gp_pak(gp_fct);
    disp(exp(w))
    
    gp_cst = GPmodel_toy(x_cst, y_cst, [], [], [1 0.1 1e-04], [], [], ...
        meanf_ind_f, jitterIndex);
    
    [w,s] = gp_pak(gp_cst);
    disp(exp(w))
    
    
    %% SECTION 3: Carry out BO
    
    i1 = 0; % no of successful BO iterations
    
    count = 0; % total no of iterations (includes those that progress or not the obj fct)
    
    % Set the options for optimizer of the acquisition function
    
    opts = optimoptions(@fmincon,'Algorithm','sqp');
    
    Ns = 10^4; % no of MC samples for EI approximation
    
    ctheta = DCmax-th; % needs to be below or equal to 0
    
    lambda = NaN(maxiter+1,1);
    rho = NaN(maxiter+1,1);
    
    % Initialise
    lambda(1) = 1; % nCons lambdas
    % one rho
    rho(1) = (min(ctheta(ctheta>0).^2))/(2*abs(min(norm_areaRs2(ctheta<=0))));
    
    globalOptimaY = inf * ones(maxiter,1); % stores all the global optima y (obj fct) points
    globalOptimaX = inf * ones(maxiter,nd); % stores all the global optima x (param) points
    
    globalOptimaXla = [];
    globalOptimaYla =[];
    
    DCmax_BO = NaN(maxiter,1); % vector with all the DCmax values from BO
    norm_aRs2 = NaN(maxiter,1); % vector with all norm areaRs2 values from BO
    
    bestCstIndex = 1;% 1: bestCstSoFar (best constraint so far), 2: bestCst (current constraint)
    
    % define the Lagrangian function
    noMax = 0; % 0: `max in, 1: max out
    
    if noMax==0
        LagrF = @(y_f, y_c, lambdak, rhok) y_f + lambdak * y_c + 1/(2*rhok) * (max(0, y_c)).^2;
    else
        LagrF = @(y_f, y_c, lambdak, rhok) y_f + lambdak * y_c + 1/(2*rhok) * (y_c.^2);
    end
    
    globalOptimaYfct_min = inf;
    
    while count < maxiter
        
        % increment the no of blackbox fct evaluations
        count = count + 1;
        
        gp_fct = gp_optim(gp_fct,x_fct,y_fct);
        gp_cst = gp_optim(gp_cst,x_cst,y_cst);
        
        %ymin is for lagrangian
        if count==1
            Y_min = min(LagrF(y_fct.*std_yfct+mean_yfct, ...
                y_cst.*std_ycst+mean_ycst, lambda(1), rho(1)));
            
        else
            Y_min = min(LA);
            
        end
        
        fh_af = @(x_new) approximateEI(x_new, gp_fct, x_fct, ...
            y_fct, mean_yfct, std_yfct, ...
            gp_cst, x_cst, y_cst, mean_ycst, std_ycst, ...
            Y_min, lambda(count), rho(count), Ns, noMax, multipleCons);
        
        Xo = lhsdesign(1,nd);
        xstart = NaN(size(Xo,1),nd);
        for j=1:nd
            xstart(:,j) = l(j) + (u(j)-l(j)) * Xo(:,j); % starting values for the BO algorithm (scaled as bounds (l,u) scaled)
        end
        
        problem = createOptimProblem('fmincon','objective',...
            fh_af,'x0',xstart,'lb',l,'ub',u,'options',opts);
        
        gs = GlobalSearch('NumTrialPoints',10^3); % !!!! 10^4 might act out, might need to go down to 10^3
        [bestX,bestAF] = run(gs,problem);
        
        bX = bestX.*sc;
        
        % calculate the obj fct value at query point by evaluating simulator
        [norm_aRs2(count), DCmax_BO(count), conS] = Run_Comsol_Simulator(bX,th);
        
        if conS==1 && norm_aRs2(count) < globalOptimaYfct_min
            % the minimum so far
            globalOptimaYfct_min = norm_aRs2(count);
            globalOptimaXfct_min = bX;
            
        end
        
        if isfinite(norm_aRs2(count))
            
            % put new sample point to the list of evaluation points for norm areaRs2
            x_fct(end+1,:) = bestX;
            y_fct = y_fct.*std_yfct+mean_yfct; % un-scale
            y_fct(end+1) = norm_aRs2(count); % on original scale
            mean_yfct = mean(y_fct); std_yfct = std(y_fct); % new mean and std
            
            y_fct = (y_fct-mean_yfct)./std_yfct; % scale back
            
            if conS == 1 % successful simulation
                
                globalOptimaY(count) = norm_aRs2(count); % y on original scale it's okay
                globalOptimaX(count,:) = bX; % x on original scale
                
                disp('successful')
                
                i1 = i1 + 1;
                
            else
                disp('unsuccessful')
                
                i1 = i1;
                
            end
            
            % put new sample point to the list of evaluation points for DCmax-th
            x_cst(end+1,:) = bestX;
            y_cst = y_cst.*std_ycst+mean_ycst; % un-scale
            ct = DCmax_BO(count)-th; bestCst = ct;
            y_cst(end+1) = ct;
            mean_ycst = mean(y_cst); std_ycst = std(y_cst); % new mean and std
            
            y_cst = (y_cst-mean_ycst)./std_ycst; % scale back
            
            globalOptimaXla = bX;
            globalOptimaYla = LagrF(norm_aRs2(count), bestCst, lambda(count,:), rho(count));
            
            LA = LagrF(y_fct.*std_yfct+mean_yfct, ...
                y_cst.*std_ycst+mean_ycst, lambda(count,:), rho(count));
            
            bestCstSoFar = y_cst(LA==min(LA),:).*std_ycst+mean_ycst;
            bestCstSoFar = bestCstSoFar(1);
            
            % Update (lambda, rho)
            lambda(count+1,:) = max(0, lambda(count,:)+1/rho(count)*bestCstSoFar);
            
            if conS == 1
                rho(count+1) = rho(count);
            else
                rho(count+1) = 0.5*rho(count);
            end
            
        end
        
        save(sprintf('/./PaperResults/Stents/3D/Stents_EI_ALBO_3D_run %d.mat',irun))
        
    end
end

exit;