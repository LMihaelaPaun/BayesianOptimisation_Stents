function [norm_areaRs2, DCmax, conSatisf, success, Rs2, drugContent, time] = Run_Comsol_Simulator(param, th)

model = mphload('StentModel_v8');

m_drug_value = param(1); D_coat_value = param(2); h_coat_value = param(3);

% Set the model parameters
model.param.set('m_drug',sprintf('%d [ug]', m_drug_value));
model.param.set('D_coat',sprintf('%d [m^2/s]', D_coat_value));
model.param.set('h_coat',sprintf('%d [um]', h_coat_value));

% First run the stationary part of the model
model.study('std1').run;

% Now solve the time-dependent drug model
try
    success = 1;
    
    model.study('std2').run;
    
    drugContent = model.result.numerical('gev4').getReal; % drug concentration in the wall
    saturationLevel = model.result.numerical('gev1').getReal; % receptor saturation level
    
    %% OBJECTIVE FUNCTION
    % get the time vector
    info = mphsolutioninfo(model);
    time = info.sol2.values{1};
    % get value of the upper receptor saturation
    Rs2 = saturationLevel(2,:);
    % calculate the area under Rs2 curve
    areaRs2 = trapz(time,Rs2);
    % calculate the normalised area above the RS2 curve --> TO MINIMISE
    norm_areaRs2 = (time(end)*100 - areaRs2)/(100*time(end));
    
    %% Max drug content constraint
    
    DCmax = max(drugContent(1,:));
    
    conSatisf = 0; % indicates whther the constraint is satisfied
    
    if DCmax < th % if below the threshold
        conSatisf = 1; % constraint is satisfied
    end
    
catch
    success = 0;
    norm_areaRs2 = Inf;
    DCmax = Inf;
    conSatisf = 0;
end

end

