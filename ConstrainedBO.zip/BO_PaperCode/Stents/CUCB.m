%%%%%%%%%%%%%%%%%
%%%%%% Run Bayesian Optimization on the stents problem %%%%%
%%% Mihaela Paun %%%

clear; close all;

%system('killall -9 comsollauncher java'); % kill previous running Comsol server instances to prevent port assignment problems

% start the comsol servers

addpath('/maths/comsol60/multiphysics/mli')
comsolPort = 2064; % set unique port
system( ['/maths/comsol60/multiphysics/bin/comsol -np 1 server -port ',num2str(comsolPort), ' &'] ); % start a Comsol server
pause( 30 ) % give Comsol server time to start up
% instead of the above, I should try the ID file writing
mphstart(comsolPort); % comsolPort is the port number

addpath(genpath('/./BO_PaperCode'))

% Add path to GPstuff toolbox
% !!!this path only contains the amplitude truncation below 10^5 in fminscg
GPpath = genpath('/./gpstuff-develop'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path

nrun = 10;

maxiter = 50; % BO budget (maximum no of function evaluations)

multipleCons = 0; % multiple constraints?

for irun=1:nrun
    
    %% SECTION 1: load pre-run initial design
    load(sprintf('/./PaperResults/Stents/3D/InitialDesign_run %d.mat', irun))
    
    %% SECTION 2: Construct initial GP model out of the simulator callings above
    
    sc = abs(u);
    
    l = l./sc; u = u./sc;
    
    conSatisf = logical(conSatisf);
    
    x_class = param./sc; y_class = 2.*conSatisf-1;
    
    x_regr = param./sc; y_regr = norm_areaRs2;
    
    %%%
    
    mean_y = mean(y_regr);
    std_y = std(y_regr);
    
    % Scale y_regr
    y_regr = (y_regr-mean_y)./std_y; % mean 0 and std 1 of of y
    
    % Build GP models (regression emulator for normalised area above Rs2)
    % and classifier for upper constraint on DC max value
    
    X_r = sobolset(nd+2, 'Skip',2e12,'Leap',0.45e15); % draw 10 values
    n_r = size(X_r, 1);
    
    l_r = [0.5 repmat(0.1,1,nd) 10^(-6)];
    u_r = [1.5 ones(1,nd) 1];
    
    % Initialisations for amplitude, lengthscale and likelihood noise for GP
    % regression
    H_r = [];
    for i=1:nd+2
        H_r = [H_r, l_r(i) + (u_r(i)-l_r(i)) * X_r(:,i)];
    end
    
    % Initialisations for amplitude and lengthscale for GP classification
    X_c = sobolset(nd+1, 'Skip',4e8,'Leap',0.45e15); % draw 21 values
    n_c = size(X_c, 1);
    
    l_c = [0.5 repmat(0.1,1,nd)];
    u_c = [1.5 ones(1,nd)];
    
    H_c = [];
    for i=1:nd+1
        H_c = [H_c, l_c(i) + (u_c(i)-l_c(i)) * X_c(:,i)];
    end
    
    jitterIndex = 1; % 1:small jitter, 2:large jitter
    
    meanf_ind_f = 0; meanf_ind_c = 2;
    % 0: zero mean for GP classifier; 1: linear mean function; 2: quadratic mean function
    
    [gp_regr, nlml_regr, gp_class, nlml_class] = ...
        GPmodel_toy(x_regr, y_regr, x_class, y_class, H_r(1:5,:), H_c, ...
        meanf_ind_c, meanf_ind_f, jitterIndex);
    
    %% SECTION 3: Carry out BO
    
    i1 = 0;
    
    % Set the options for optimizer of the acquisition function
        
    optimf = @fmincon;
    optdefault=struct('LargeScale','off','Algorithm','SQP','TolFun',1e-8,'TolX',1e-8, 'display', 'off');
    opt=optimset(optdefault);
    
    noInit = 250; % no of initialisations for the BO algorithm
    
    DCmax_BO = NaN(maxiter,1);
    norm_aRs2 = NaN(maxiter,1);
    
    globalOptimaY = inf * ones(maxiter,1); % stores all the global optima y (obj fct) points
    globalOptimaX = inf * ones(maxiter,nd); % stores all the global optima x (param) points
    
    count = 0; % total no of iterations (includes those that progress or not the obj fct)
    
    globalOptimaYfct_min = inf;
    
    delta = 0.1; % needed for UCB calculation
    
    minUCB_idx = 1; % needed for UCB calculation (minimise fx)
    
    tst = 1; % which test statistic we optimise in ucb_hcw_entropy
    alp1=1; alp2=1; w=NaN; % parameters for the test statistic
    
    while count < maxiter
        
        count = count + 1;
        
        betaC = 2*log((pi^2*(count+1)^(nd/2+2))/(3*delta));
        
        gp_regr = gp_optim(gp_regr,x_regr,y_regr);
        gp_class = gp_optim(gp_class,x_class,y_class);
        
        fh_af = @(x_new) ucb_hcw_entropy(x_new, gp_regr, x_regr, ...
            gp_class, x_class, y_class, betaC, y_regr, mean_y, std_y, minUCB_idx, ...
            tst, alp1, alp2, w, multipleCons);
        
        Xo = lhsdesign(noInit,nd);
        xstart = NaN(size(Xo,1),nd);
        for j=1:nd
            xstart(:,j) = l(j) + (u(j)-l(j)) * Xo(:,j); % starting values for the BO algorithm
        end
        
        x_new = NaN(size(xstart,1),nd);
        AFs = NaN(size(xstart,1),1);
        
        for s1=1:size(xstart,1)
            try
                [x_new(s1,:),AFs(s1)] = optimf(fh_af, xstart(s1,:), [], [], [], [], l, u, [], opt);
            catch
                AFs(s1) = inf; x_new(s1,:) = inf;
            end
        end
        
        
        % pick up the point where HCW-Expected Improvement is maximized
        bestAF = min(AFs); bestAF=bestAF(1);
        bestX = x_new(AFs==bestAF,:); bestX = bestX(1,:);
        
        bX = bestX.*sc;
        
        % calculate the obj fct value at query point by evaluating simulator
        [norm_aRs2(count), DCmax_BO(count), conS] = Run_Comsol_Simulator(bX,th);
        
        if conS == 1 && norm_aRs2(count) < globalOptimaYfct_min
            % the minimum so far
            globalOptimaYfct_min = norm_aRs2(count);
            globalOptimaXfct_min = bX;
        end
        
        if isfinite(norm_aRs2(count))
            
            % put new sample point to the list of evaluation regression points
            x_regr(end+1,:) = bestX;
            y_regr = y_regr.*std_y+mean_y; % un-scale
            y_regr(end+1) = norm_aRs2(count); % on original scale
            mean_y = mean(y_regr); std_y = std(y_regr); % new mean and std
            
            y_regr = (y_regr-mean_y)./std_y; % scale back
            
            
            % put new sample point to the list of evaluation classification points
            x_class(end+1,:) = bestX; y_class(end+1) = 2.*conS-1;
            
            if conS == 1 % check only for the global minima from current and previous BO iteration
                
                globalOptimaY(count) = norm_aRs2(count); % y on original scale it's okay
                globalOptimaX(count,:) = bX; % x on original scale
                
                disp('successful')
                
                i1 = i1 + 1;
                
            else % consS(1) = 0
                disp('unsuccessful -- try another iteration to optimise!')
                i1 = i1; % we do not increment counter for PDE evaluations
            end
            
        end
        
        save(sprintf('/./PaperResults/Stents/3D/Stents_CUCB_BO_3D_run %d.mat', irun))
                
    end
    
end

exit;