%%%%%%%%%%%%%%%%%
%%%%%% Run Bayesian Optimization on a toy problem %%%%%
%%% Mihaela Paun %%%

clear; close all;

addpath(genpath('/./BO_PaperCode'))

% Add path to GPstuff toolbox
% !!!this path only contains the amplitude truncation below 10^5 in fminscg
GPpath = genpath('/./gpstuff-develop'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path

%% SECTION 1: Run the model for a number of parameter values from a space filling design
th = 0; % threshold value

nd = 5; % no of parameters

nCons=6; %no of constraints

nrun = 30;

maxiter = 100; % BO budget (maximum no of function evaluations)

discreteOptim = 0;

multipleCons = 1; % multiple constraints

for irun=1:nrun
    
    % lower and upper bounds (need them inside the loop as after irun>1, l
    % and u are scaled between 0 and 1, but we need them rescaled back to original when drawing from space filling design)

    l = [78, 33, 27, 27, 27];
    u = [102, 45, 45, 45, 45];
    
    rng(irun,'twister')
    
    X = lhsdesign(nd*10,nd);
    
    param = l + (u-l) .* X;
    
    fct_eval = ObjFct(param);
    
    C_eval = ConsFct(param);%, nCons);
    
    conSatisf = C_eval<th;
    
    
    %% SECTION 2: Construct initial GP model out of the simulator callings above
    
    sc = abs(u);
    
    l = l./sc; u = u./sc;
    
    conSatisf = logical(conSatisf); conSatisf = conSatisf';
    
    % Construct GPs
    x_class = param./sc;
    
    y_class = 2.*conSatisf-1; y_class=y_class';
    
    %x_regr = param(conSatisf)./sc; y_regr = fct_eval(conSatisf);
    x_regr = param./sc; y_regr = fct_eval;
    
    %%%
    
    mean_y = mean(y_regr);
    std_y = std(y_regr);
    
    % Scale y_regr
    y_regr = (y_regr-mean_y)./std_y; % mean 0 and std 1 of of y
    
    % Build GP models (regression emulator for normalised area above Rs2)
    % and classifier for upper constraint on DC max value
    
    X_r = sobolset(nd+2, 'Skip',2e12,'Leap',0.45e15); % draw 10 values
    n_r = size(X_r, 1);
    
    l_r = [0.5 repmat(0.1,1,nd) 10^(-6)];
    u_r = [1.5 ones(1,nd) 1];
    
    % Initialisations for amplitude, lengthscale and likelihood noise for GP
    % regression
    H_r = [];
    for i=1:nd+2
        H_r = [H_r, l_r(i) + (u_r(i)-l_r(i)) * X_r(:,i)];
    end
    
    % Initialisations for amplitude and lengthscale for GP classification
    X_c = sobolset(nd+1, 'Skip',4e8,'Leap',0.45e15); % draw 21 values
    n_c = size(X_c, 1);
    
    l_c = [0.5 repmat(0.1,1,nd)];
    u_c = [1.5 ones(1,nd)];
    
    H_c = [];
    for i=1:nd+1
        H_c = [H_c, l_c(i) + (u_c(i)-l_c(i)) * X_c(:,i)];
    end
    
    jitterIndex = 2; % 1:small jitter, 2:large jitter
    
    meanf_ind_f=0; meanf_ind_c=2; % quadratic mean
    
    for iCons = 1:nCons
        if iCons==1
            [gp_regr, nlml_regr, gp_class{iCons}, nlml_class] = ...
                GPmodel_toy(x_regr, y_regr, x_class, y_class(:,iCons), H_r, H_c(1,:), ...
                meanf_ind_c,meanf_ind_f,jitterIndex);
        else
            [~,~, gp_class{iCons}, ~] = ...
                GPmodel_toy(x_regr, y_regr, x_class, y_class(:,iCons), [], H_c(1,:), ...
                meanf_ind_c,meanf_ind_f,jitterIndex);
        end
    end
    
    %% SECTION 3: Carry out BO
    
    i1 = 0; % no of successful BO iterations
    
    % Set the options for optimizer of the acquisition function
    
    opts = optimoptions(@fmincon,'Algorithm','sqp');
    
    globalOptimaY = inf * ones(maxiter,1); % stores all the global optima y (obj fct) points
    globalOptimaX = inf * ones(maxiter,nd); % stores all the global optima x (param) points
    
    count = 0; % total no of iterations (includes those that progress or not the obj fct)
    
    globalOptimaYfct_min = inf;
    
    tst = 3; % which test statitic we optimise in expectedImprovement_hcw_entropy
    alp1=1; alp2=5; w=2/3; % parameters for the test statistic
    
    while count < maxiter % && improv>1e-6
        
        count = count + 1;
        
        [K, C] = gp_trcov(gp_regr,x_regr);
        invC = inv(C);
        a = C\y_regr;
        fmin = min(y_regr(all(y_class'==1)));
        
        fh_af = @(x_new) expectedimprovement_hcw_entropy(x_new, gp_regr, x_regr, a, invC,...
            fmin, gp_class, x_class, y_class, mean_y, std_y, tst, alp1, alp2, w, multipleCons);
        
        if discreteOptim==1
            Xstar = lhsdesign(10^3,1);
            xstar=l + (u-l) .* Xstar;
            AFstar = fh_af(xstar);
            xstart = xstar(AFstar==min(AFstar));
            
            bestX = xstart;
            
        else
            
            Xo = lhsdesign(1,nd);
            xstart = NaN(size(Xo,1),nd);
            for j=1:nd
                xstart(:,j) = l(j) + (u(j)-l(j)) * Xo(:,j); % starting values for the BO algorithm
            end
            
            problem = createOptimProblem('fmincon','objective',...
                fh_af,'x0',xstart,'lb',l,'ub',u,'options',opts);
            
            gs = GlobalSearch('NumTrialPoints',10^3);
            [bestX,bestAF] = run(gs,problem);
            
        end
        
        bX = bestX.*sc;
        
        bestObjF= ObjFct(bX);
        
        bestCst = ConsFct(bX)-th;
        
        conS = all(bestCst<10^(-4));
        
        if conS == 1 && bestObjF < globalOptimaYfct_min
            % the minimum so far
            globalOptimaYfct_min = bestObjF;
            globalOptimaXfct_min = bX;
        end
        
        % put new sample point to the list of evaluation regression points
        x_regr(end+1,:) = bestX;
        y_regr = y_regr.*std_y+mean_y; % un-scale
        y_regr(end+1) = bestObjF; % on original scale
        mean_y = mean(y_regr); std_y = std(y_regr); % new mean and std
        
        y_regr = (y_regr-mean_y)./std_y; % scale back
        
        if conS == 1 % successful simulation
            
            globalOptimaY(count) = bestObjF; % y on original scale it's okay
            globalOptimaX(count,:) = bX; % x on original scale
            
            disp('successful')
            
            i1 = i1 + 1;
            
        else
            disp('unsuccessful')
            
            i1 = i1;
            
        end
        
        % put new sample point to the list of evaluation classification points
        x_class(end+1,:) = bestX;
        y_class(end+1,:) = 2*(bestCst<10^(-4))-1;
        
        try
            gp_regr = gp_optim(gp_regr,x_regr,y_regr);
            
            for iCons = 1:nCons
                gp_class{iCons} = gp_optim(gp_class{iCons},x_class,y_class(:,iCons));
            end
            
        catch
            
            for iCons = 1:nCons
                if iCons==1
                    
                    [gp_regr, nlml_regr, gp_class{iCons}, nlml_class] = ...
                        GPmodel_toy(x_regr, y_regr, x_class, y_class(:,iCons), H_r, H_c(1,:), ...
                        meanf_ind_c,meanf_ind_f,jitterIndex,multipleCons);
                else
                    [~,~, gp_class{iCons}, ~] = ...
                        GPmodel_toy(x_regr, y_regr, x_class, y_class(:,iCons), [], H_c(1,:), ...
                        meanf_ind_c,meanf_ind_f,jitterIndex,multipleCons);
                    
                end
                
            end
        end
        
        if discreteOptim==1
            save(sprintf('/./PaperResults/ToyProblems/Example5D_6Cons/EI_entropy_discreetOptim_run %d.mat', irun))
            
        else
            save(sprintf('/./PaperResults/ToyProblems/Example5D_6Cons/EI_entropy_run %d.mat', irun))
        end
        
    end
    
end

exit;

% G4
function OF = ObjFct(x)

OF = 5.3578547*x(:,3).^2+0.8356891*x(:,1).*x(:,5)+37.293239*x(:,1)-40792.141;

end

function CF = ConsFct(x)

u = 85.334407+0.0056858*x(:,2).*x(:,5)+0.0006262*x(:,1).*x(:,4)-0.0022053*x(:,3).*x(:,5);
CF(:,1) = -u;
CF(:,2) = u-92;
v = 80.51249+0.0071317*x(:,2).*x(:,5)+0.0029955*x(:,1).*x(:,2)+0.0021813*x(:,3).^2;
CF(:,3) = -v+90;
CF(:,4) = v-110;
w = 9.300961+0.0047026*x(:,3).*x(:,5)+0.0012547*x(:,1).*x(:,3)+0.0019085*x(:,3).*x(:,4);
CF(:,5) = -w+20;
CF(:,6) = w-25;

end