%%%%%%%%%%%%%%%%%
%%%%%% Run Bayesian Optimization on a toy problem %%%%%
%%% Mihaela Paun %%%

clear; close all;

addpath(genpath('/./BO_PaperCode'))

% Add path to GPstuff toolbox
% !!!this path only contains the amplitude truncation below 10^5 in fminscg
GPpath = genpath('/./gpstuff-develop'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path

%% SECTION 1: Run the model for a number of parameter values from a space filling design
th = 0; % threshold value

nd = 5; % no of parameters

nCons=6; %no of constraints

nrun = 30;

maxiter = 100; % BO budget (maximum no of function evaluations)

discreteOptim = 0;

multipleCons = 1; % multiple constraints

for irun=1:nrun
    
    % lower and upper bounds (need them inside the loop as after irun>1, l
    % and u are scaled between 0 and 1, but we need them rescaled back to original when drawing from space filling design)
    
    l = [78, 33, 27, 27, 27];
    u = [102, 45, 45, 45, 45];
    
    rng(irun,'twister')
    
    X = lhsdesign(nd*10,nd);
    
    param = l + (u-l) .* X;
    
    fct_eval = ObjFct(param);
    
    C_eval = ConsFct(param);%, nCons);
    
    conSatisf = C_eval<th;
    
    
    %% SECTION 2: Construct initial GP model out of the simulator callings above
    
    sc = abs(u);
    
    l = l./sc; u = u./sc;
    
    conSatisf = logical(conSatisf); conSatisf = conSatisf';
    
    % Construct GPs
    x_fct = param./sc; y_fct = fct_eval;
    
    x_cst = param./sc; y_cst = C_eval - th;
    
    mean_yfct = mean(y_fct);
    std_yfct = std(y_fct);
    % Scale
    y_fct = (y_fct-mean_yfct)./std_yfct; % mean 0 and std 1 of of y
    
    mean_ycst = mean(y_cst);
    std_ycst = std(y_cst);
    % Scale
    y_cst = (y_cst-mean_ycst)./std_ycst; % mean 0 and std 1 of of y
    
    % Build GP regression models
    
    X_r = sobolset(nd+2, 'Skip',2e12,'Leap',0.45e15); % draw 10 values
    n_r = size(X_r, 1);
    
    l_r = [0.5 repmat(0.1,1,nd) 10^(-6)];
    u_r = [1.5 ones(1,nd) 1];
    
    % Initialisations for amplitude, lengthscale and likelihood noise for GP
    % regression
    H_r = [];
    for i=1:nd+2
        H_r = [H_r, l_r(i) + (u_r(i)-l_r(i)) * X_r(:,i)];
    end
    
    jitterIndex = 1; % 1:small jitter, 2:large jitter
    
    meanf_ind_f=0;
    
    gp_fct = GPmodel_toy(x_fct, y_fct, [], [], [1 0.1 1e-04], ...
        [], [], meanf_ind_f, jitterIndex);
    
    for iCons = 1:nCons
        gp_cst{iCons} = GPmodel_toy(x_cst, y_cst(:,iCons), [], [], [1 0.1 1e-04], ...
            [], [], meanf_ind_f, jitterIndex);
    end
    
    %% SECTION 3: Carry out BO
    
    i1 = 0; % no of BO iterations -- no of iterations when constraint satisfied
    
    count = 0; % total no of iterations (includes those that progress or not the obj fct)
    
    optimf = @fmincon;
    optdefault=struct('LargeScale','off','Algorithm','SQP','TolFun',1e-8,'TolX',1e-8, 'display', 'off');
    opt=optimset(optdefault);
    
    noInit = 250; % no of initialisations for the BO algorithm
    
    % for computation of cov(y_c,max(0,y_c)^2) if max term in
    
    T = 10^2; % no of MC samples for covariance approximation
    Ns = 10^2; % no of posterior samples drawn
    
    ctheta = C_eval-th; % all entries need to be below or equal to 0
    
    kmax = 50; % max no of (lambda, rho) updates
    
    k = 2; % index for (lambda, rho)
    
    lambda = NaN(kmax,nCons); %mpaun
    rho = NaN(kmax,1);
    
    % Initialise
    lambda(1,:) = ones(1,nCons); % nCons lambdas
    % one rho
    rho(1) = (min((sum(ctheta(any(ctheta>0,2),:).^2,1))))/(2*abs(min(fct_eval(all(ctheta<=0,2)))));
    
    update = 0; % indicates if we have updated (lambda,rho)
    
    globalOptimaY = inf * ones(maxiter,1); % stores all the global optima y (obj fct) points
    globalOptimaX = inf * ones(maxiter,nd); % stores all the global optima x (param) points
    
    globalOptimaYla = []; % stores all the global optima y (LA) points
    globalOptimaXla = []; % stores all the global optima x (param) points that maximise LA
    
    bestCstIndex = 2;%1 mpaun % 1: bestCstSoFar (best constraint so far), 2: bestCst (current constraint)
    
    % define the Lagrangian function
    noMax = 1; %0
    
    if noMax==0
        LagrF = @(y_f, y_c, lambdak, rhok) y_f + y_c*lambdak' + 1/(2*rhok) * sum((max(0, y_c)).^2,2);
    else
        LagrF = @(y_f, y_c, lambdak, rhok) y_f + y_c*lambdak' + 1/(2*rhok) * sum(y_c.^2,2);
    end
    
    globalOptimaYfct_min = inf;
    
    delta = 0.1; % needed for UCB calculation
    
    minUCB_idx = 1; % needed for UCB calculation (minimise fx)
    
    while count < maxiter % && improv>1e-6
        
        count = count + 1;
        
        % update GPs
        gp_fct = gp_optim(gp_fct,x_fct,y_fct);
        for icons=1:nCons
            gp_cst{icons} = gp_optim(gp_cst{icons},x_cst,y_cst(:,icons));
        end
        
        betaC = 2*log((pi^2*(count+1)^(nd/2+2))/(3*delta));
        
        fh_af = @(x_new) ucb_hcw_AL(x_new, gp_fct, x_fct, y_fct, ...
            gp_cst, x_cst, y_cst, mean_yfct, std_yfct, mean_ycst, std_ycst, ...
            lambda(k-1,:), rho(k-1), Ns, T, betaC, minUCB_idx, noMax, multipleCons);
        
        if discreteOptim==1
            Xstar = lhsdesign(10^3,1);
            xstar=l + (u-l) .* Xstar;
            AFstar = fh_af(xstar);
            xstart = xstar(AFstar==min(AFstar));
            
            bestX = xstart;
            
        else
            
            Xo = lhsdesign(noInit,nd);
            xstart = NaN(size(Xo,1),nd);
            for j=1:nd
                xstart(:,j) = l(j) + (u(j)-l(j)) * Xo(:,j); % starting values for the BO algorithm
            end
            
            x_new = NaN(size(xstart,1),nd);
            AFs = NaN(size(xstart,1),1);
            
            parfor s1=1:size(xstart,1)
                try
                    [x_new(s1,:),AFs(s1)] = optimf(fh_af, xstart(s1,:), [], [], [], [], l, u, [], opt);
                catch
                    AFs(s1) = inf; x_new(s1,:) = inf;
                end
            end
            
            
            % pick up the point where HCW-Expected Improvement is maximized
            bestAF = min(AFs); bestAF=bestAF(1);
            bestX = x_new(AFs==bestAF,:); bestX = bestX(1,:);
            
        end
        
        bX = bestX.*sc;
        
        bestObjF= ObjFct(bX);
        
        bestCst = ConsFct(bX)-th;
        
        conS = all(bestCst<10^(-4));
        
        if conS == 1 && bestObjF < globalOptimaYfct_min
            % the minimum so far
            globalOptimaYfct_min = bestObjF;
            globalOptimaXfct_min = bX;
        end
        
        % put new sample point to the list of evaluation regression points
        x_fct(end+1,:) = bestX;
        y_fct = y_fct.*std_yfct+mean_yfct; % un-scale
        y_fct(end+1) = bestObjF; % on original scale
        mean_yfct = mean(y_fct); std_yfct = std(y_fct); % new mean and std
        
        y_fct = (y_fct-mean_yfct)./std_yfct; % scale back
        
        if conS == 1 % successful simulation
            
            globalOptimaY(count) = bestObjF; % y on original scale it's okay
            globalOptimaX(count,:) = bX; % x on original scale
            
            disp('successful')
            
            i1 = i1 + 1;
            
        else
            disp('unsuccessful')
            
            i1 = i1;
            
        end
        
        % put new sample point to the list of evaluation classification points
        x_cst(end+1,:) = bestX;
        y_cst = y_cst.*std_ycst+mean_ycst; % un-scale
        y_cst(end+1,:) = bestCst;
        mean_ycst = mean(y_cst); std_ycst = std(y_cst); % new mean and std
        
        y_cst = (y_cst-mean_ycst)./std_ycst; % scale back
        
        %mpaun
        LA = LagrF(bestObjF, bestCst, lambda(k-1,:), rho(k-1)); % original scale
        
        if update == 0
            previousL = LA;
        end
        
        globalOptimaYla = [globalOptimaYla LA]; % y on original scale it's okay
        globalOptimaXla = [globalOptimaXla; bX]; % x on original scale
        
        % check if any improvement: L(theta_k, lambda_k-1, rho_k-1) <
        % L(theta_k-1, lambda_k-1, rho_k-1)
        
        if update==1
            improv_LA = LA-previousL; % ensure previousL is from same lambda, rho
            
        else % the first LA evaluation for the current (lambda,rho)
            improv_LA = 0;
        end
        
        if improv_LA > 0
            
            LAall = LagrF(y_fct.*std_yfct+mean_yfct, ...
                y_cst.*std_ycst+mean_ycst, lambda(k-1,:), rho(k-1));
            
            bestCstSoFar = y_cst(LAall==min(LAall),:).*std_ycst+mean_ycst;
            %bestCstSoFar=bestCstSoFar(1,:);
            
            if bestCstIndex == 1
                % Update (lambda, rho) once there is an improvement
                lambda(k,:) = max(0, lambda(k-1,:)+1/rho(k-1)*bestCstSoFar);
                
            else
                % Update (lambda, rho) once there is an improvement
                lambda(k,:) = max(0, lambda(k-1,:)+1/rho(k-1)*bestCst);
                
            end
            
            lambda(k,:)
            
            if conS == 1
                rho(k) = rho(k-1);
            else
                rho(k) = 0.5*rho(k-1);
            end
            
            k = k+1;
            
            update = 0;
            
        else %improve <= 0
            
            update = 1;
            
        end
        
        if discreteOptim==1
            
            save(sprintf('/./PaperResults/ToyProblems/Example5D_6Cons/UCB_ALBO_discreetOptim_run %d.mat', irun))
            
        else
            
            save(sprintf('/./PaperResults/ToyProblems/Example5D_6Cons/UCB_ALBO_run %d.mat', irun))
            
        end
    end
    
end

exit;

% G4
function OF = ObjFct(x)

OF = 5.3578547*x(:,3).^2+0.8356891*x(:,1).*x(:,5)+37.293239*x(:,1)-40792.141;

end

function CF = ConsFct(x)

u = 85.334407+0.0056858*x(:,2).*x(:,5)+0.0006262*x(:,1).*x(:,4)-0.0022053*x(:,3).*x(:,5);
CF(:,1) = -u;
CF(:,2) = u-92;
v = 80.51249+0.0071317*x(:,2).*x(:,5)+0.0029955*x(:,1).*x(:,2)+0.0021813*x(:,3).^2;
CF(:,3) = -v+90;
CF(:,4) = v-110;
w = 9.300961+0.0047026*x(:,3).*x(:,5)+0.0012547*x(:,1).*x(:,3)+0.0019085*x(:,3).*x(:,4);
CF(:,5) = -w+20;
CF(:,6) = w-25;

end