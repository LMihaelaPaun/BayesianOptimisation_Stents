function [avgEI, Y_LF, PostDraws_f, PostDraws_c] = ...
    approximateEI(theta, gp_f, x_f, y_f, mean_yf, std_yf, ...
    gp_c, x_c, y_c, mean_yc, std_yc, Y_min, lambda, rho, Ns, noMax, multipleCons)
% function that calculates EI numerically by MC

% need to input lambda(k-1), rho(k-1) at iteration k

if multipleCons == 0
    
    if noMax==0
        LagrF = @(y_f, y_c, lambdak, rhok) y_f + lambdak * y_c + 1/(2*rhok) * (max(0, y_c)).^2;
    else
        LagrF = @(y_f, y_c, lambdak, rhok) y_f + lambdak * y_c + 1/(2*rhok) * (y_c.^2);
    end
    
else
    %     if noMax==0
    %         LagrF = @(y_f, y_c, lambdak, rhok) y_f + reshape(pagemtimes(lambdak,y_c),Ns,[]) + 1/(2*rhok) * reshape(sum((max(0, y_c)).^2),Ns,[]);
    %     else
    %         LagrF = @(y_f, y_c, lambdak, rhok) y_f + reshape(pagemtimes(lambdak,y_c),Ns,[]) + 1/(2*rhok) * reshape(sum(y_c.^2,1),Ns,[]);
    %     end
    
    if noMax==0
        LagrF = @(y_f, y_c, lambdak, rhok) y_f + y_c*lambdak' + 1/(2*rhok) * sum((max(0, y_c)).^2,2);
    else
        LagrF = @(y_f, y_c, lambdak, rhok) y_f + y_c*lambdak' + 1/(2*rhok) * sum(y_c.^2,2);
    end
    
end

% sample Ns samples from GP post distribution of f and c
PostDraws_f = drawGPsamples(theta, gp_f, x_f, y_f, Ns);

if multipleCons == 0
    
    PostDraws_c = drawGPsamples(theta, gp_c, x_c, y_c, Ns);
    
else
    
    nCons = size(mean_yc,2);
    for icons=1:nCons
        PostDraws_c(:,icons)  = drawGPsamples(theta, gp_c{icons}, x_c, y_c(:,icons), Ns);
    end
    
end

% Scale the posterior draws to original scale
PostDraws_f = PostDraws_f.*std_yf + mean_yf;
PostDraws_c = PostDraws_c.*std_yc + mean_yc;

% compute Lagrangian function evaluations (original scale)
Y_LF = LagrF(PostDraws_f, PostDraws_c, lambda, rho); % should be (Ns,1) size

% average to get expected improvement

avgEI = mean(max(0,Y_min - Y_LF));

% minimise negative expected improvement
avgEI = - avgEI;

    function PostDraws = drawGPsamples(theta, gp, x, y, Ns)
        % Function that draws Ns samples from a GP posterior distribution
        
        % need the posterior mean and posterior covariance matrix
        postMean = gp_pred(gp, x, y, theta);
        
        s2 = gp.lik.sigma2;
        
        n = size(x,1);
        
        A = gp_trcov(gp, theta); %gp_trvar(gp, theta); % either works
        C = gp_trcov(gp, x) + s2*eye(n, n); % we update the gp and x at every BO iteration, so we need to re-obtain C every time
        B = gp_cov(gp, theta, x);
        %%%% B_t = gp_cov(gp, x, theta); this is simply B'
        
        postCovMat = A - B/C*B' + s2*eye(size(theta,1));
        
        if ~issymmetric(postCovMat)
            postCovMat = (postCovMat+postCovMat')/2; % to make it symmetric
        end
        
        PostDraws = mvnrnd(postMean, postCovMat, Ns);
        
    end

end

