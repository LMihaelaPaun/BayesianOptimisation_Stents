function [AF_B, bm_part, AF, CDFpart, PDFpart, Varf_f] = ...
    barrierMethodAcqF(x_new, gp_f, x_f, y_f, mean_yf, std_yf, ...
    gp_c, x_c, y_c, mean_yc, std_yc, fmin, BM_ind, AF_ind, ...
    minUCB_idx, beta, multipleCons)
%

[Ef_f, Varf_f] = gp_pred(gp_f,x_f,y_f, x_new);

Ef_f = Ef_f*std_yf+mean_yf;
Varf_f = Varf_f*(std_yf^2);

n_xnew = size(x_new,1);

bm_part = -10^10 * ones(n_xnew,1);

if multipleCons == 0
    
    [Ef_c, Varf_c] = gp_pred(gp_c,x_c,y_c, x_new);
    Ef_c = Ef_c*std_yc+mean_yc;
    Varf_c = Varf_c*(std_yc^2);
    
    
    bm_part(Ef_c<0) = Varf_f(Ef_c<0) .* (log(-Ef_c(Ef_c<0)) + Varf_c(Ef_c<0)./(2*Ef_c(Ef_c<0).^2));
    
else
    
    nCons = size(mean_yc,2);
    
    Ef_c = NaN(n_xnew,nCons);
    Varf_c = NaN(n_xnew,nCons);
    
    for j=1:nCons
        [Ef_c(:,j), Varf_c(:,j)] = gp_pred(gp_c{j},x_c,y_c(:,j), x_new);
        Ef_c(:,j) = Ef_c(:,j)*std_yc(j)+mean_yc(j);
        Varf_c(:,j) = Varf_c(:,j)*(std_yc(j)^2);
    end
    
    bm_part(all(Ef_c'<0)) = Varf_f(all(Ef_c'<0)) .* ...
        sum( (log(-Ef_c(all(Ef_c'<0),:)) + Varf_c(all(Ef_c'<0),:)./(2*Ef_c(all(Ef_c'<0),:).^2)), 2 ); %sum over the no of constraints
    
end

if BM_ind == 1
    
    AF_B = -Ef_f + bm_part;
    
    AF = NaN;
    
else
    
    if AF_ind == 1 % EI
        % Calculate expected improvement if there are training points for it
        fmin=fmin*std_yf+mean_yf;
        %
        
        % expected improvement (we maximise this)
        posvar=find(Varf_f>0);
        CDFpart = zeros(size(Varf_f));
        PDFpart = zeros(size(Varf_f));
        tmp = (fmin - Ef_f(posvar))./sqrt(Varf_f(posvar));
        CDFpart(posvar) = normcdf(tmp);
        CDFpart(~posvar) = (fmin - Ef_f(~posvar))>0;
        PDFpart(posvar) = normpdf(tmp);
        EI =  (fmin - Ef_f).*CDFpart + sqrt(Varf_f).*PDFpart; % maximise this when we minimise true fct f(x), i.e. we minimise Ef, hence maximise -Ef, and maximise Varf also
        
        AF = EI; % maximise this
        
    else % UCB
        
        if minUCB_idx == 1 % we minimise f(x) true fct
            UCB = Ef_f -  beta .* sqrt(Varf_f); % minimise this
            UCB = -UCB; % maximise this
        else % we maximise f(x) true fct
            UCB = Ef_f +  beta .* sqrt(Varf_f); % maximise this
            %UCB = -UCB; % minimise this
        end
        
        AF = UCB; % maximise this
        
    end
    
    AF_B = AF + bm_part; % maximise this
    
end

AF_B = -AF_B; % minimise this

end