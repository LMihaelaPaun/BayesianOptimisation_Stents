function [gp_regr, nlml_regr, gp_class, nlml_class] = ...
    GPmodel_toy_CEItest6(x_regr, y_regr, x_class, y_class, H_r, H_c, meanf_ind_c, meanf_ind_f)
% Fits and return GP regression and GP classification model to x and y
%% GP regression

% Hyperpriors
plg = prior_logunif(); % prior for lengthscale
pms = prior_logunif(); % prior for amplitude
ps = prior_logunif(); % prior for sigma2 in the likelihood

for i = 1:size(H_r,1)
     lik = lik_gaussian('sigma2', 10^(-1), 'sigma2_prior', prior_fixed); % lower sigma2 value leads to numerical instabilities
     
    % use stationary (squared exponenetial) cov fct
    gpcf = gpcf_neuralnetwork();
    
    % Set a small amount of jitter to be added to the diagonal elements of the
    % covariance matrix K to avoid singularities when this is inverted
    jitter=0;
    
    if meanf_ind_f == 1
    % Initialize base functions for GP's mean function.
gpmf1 = gpmf_constant('prior_mean',0,'prior_cov',100);
gpmf2 = gpmf_linear('prior_mean',0,'prior_cov',100); % -1, 10
gpmf3 = gpmf_squared('prior_mean',0,'prior_cov',100,'interactions','on');
  
    % Create the GP structure
    gp_regr_all{i} = gp_set('lik', lik, 'cf', gpcf, 'jitterSigma2', jitter,...
        'meanf', {gpmf1,gpmf2,gpmf3});
    
    else
        % Create the GP structure
    gp_regr_all{i} = gp_set('lik', lik, 'cf', gpcf, 'jitterSigma2', jitter);
    end
    
    %     % Set the options for the optimization
    %     opt=optimset('TolFun',1e-6,'TolX',1e-6);
    
    % Optimize with the scaled conjugate gradient method
    [gp_regr_all{i}, nlml_regr(i)] = ...
        gp_optim(gp_regr_all{i},x_regr,y_regr);%,'opt',opt);
    
end

I = find(nlml_regr == min(nlml_regr(i)));
gp_regr = gp_regr_all{I};
disp('done')

if isempty(H_c) == 0
    %% GP classifier to learn the boundary where constraint is not satisfied
    lik_class = lik_probit(); %changed from probit to logit for cei and ei entropy multiple cons 2d, if logit okay, re-run the other 2 methods for multiplecons
    
    for i = 1:size(H_c,1)
        gpcf = gpcf_sexp('lengthScale', H_c(i,2:end), ...
            'magnSigma2', H_c(i,1),...
            'lengthScale_prior', plg, 'magnSigma2_prior', pms);
        
        % Initialize base functions for GP's mean function.
        gpmf1 = gpmf_constant('prior_mean',0,'prior_cov',100);
        gpmf2 = gpmf_linear('prior_mean',0,'prior_cov',100); % -1, 10
        gpmf3 = gpmf_squared('prior_mean',0,'prior_cov',100,'interactions','on');
        

        % Initialize gp structure
        if meanf_ind_c == 0 % mean zero
            gp_class_all{i} = gp_set('lik', lik_class, 'cf', gpcf, ...
                'jitterSigma2', 1e-4,'latent_method', 'EP');
        elseif meanf_ind_c == 1 % linear mean function
            gp_class_all{i}  = gp_set('lik', lik_class, 'cf', gpcf, 'meanf', {gpmf1,gpmf2},...
                'jitterSigma2', 1e-4,'latent_method', 'EP');
        else % meanf_ind_c == 2
            gp_class_all{i}  = gp_set('lik', lik_class, 'cf', gpcf, 'meanf', {gpmf1,gpmf2,gpmf3},...
                'jitterSigma2', 1e-4,'latent_method', 'EP');
        end
        
    
        % Set the options for the optimization
        opt=optimset('TolFun',1e-3,'TolX',1e-3);
        % Optimize with the scaled conjugate gradient method
        [gp_class_all{i}, nlml_class(i)] = ...
            gp_optim(gp_class_all{i}, x_class,y_class,'opt',opt);%,'optimf', @fminlbfgs);
    end
    
    I = find(nlml_class == min(nlml_class(i)));
    gp_class = gp_class_all{I};
    
else
    gp_class = NaN;
    nlml_class = NaN;
end

end

