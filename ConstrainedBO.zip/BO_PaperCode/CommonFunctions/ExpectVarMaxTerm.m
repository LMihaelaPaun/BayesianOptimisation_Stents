function [EMaxTerm, VarMaxTerm] = ExpectVarMaxTerm(x_new, gp, x, y, mean_y, std_y, fmin)
% computes E and Var of max term in UCB-AL
% called by ucb_hcw_AL

[Ef, Varf] = gp_pred(gp, x, y, x_new);

Ef = Ef.*std_y+mean_y; Ef=-Ef;
Varf = Varf.*(std_y^2);

%
posvar=find(Varf>0);
CDFpart = zeros(size(Varf));
PDFpart = zeros(size(Varf));
tmp = (fmin - Ef(posvar))./sqrt(Varf(posvar));
CDFpart(posvar) = normcdf(tmp);
CDFpart(~posvar) = (fmin - Ef(~posvar))>0;
PDFpart(posvar) = normpdf(tmp);

s = sqrt(Varf);
u = (fmin-Ef)./s;

EMaxTerm = s.^2 .* ((u.^2+1).*CDFpart + u.*PDFpart);
VarMaxTerm = s.^4 .* ( -(u.^2+1).^2 .* (CDFpart.^2) + (u.^4+6.*(u.^2)+3) .* CDFpart - ...
    u.^2 .* (PDFpart.^2)+ (u.^3+5.*u) .* PDFpart - 2.*u.*(u.^2+1).*CDFpart.*PDFpart );

% E4maxTerm = s.^4 .* ( (u.^4+6*u.^2+3) .* CDFpart + (u.^3+5.*u) .*PDFpart);
% 
% VarMaxTerm_check = E4maxTerm - EMaxTerm.^2;
% [VarMaxTerm,VarMaxTerm_check] % should be equal
end