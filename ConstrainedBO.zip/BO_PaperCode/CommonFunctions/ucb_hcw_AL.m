function [UCB, Ef_AL, Ef_f, Ef_c] = ucb_hcw_AL(x_new, gp_f, x_f, y_f, gp_c, x_c, y_c, ...
    mean_yf, std_yf, mean_yc, std_yc, lambda, rho, Ns, T, beta, minUCB_idx, noMax, multipleCons)

% Calculate upper confidence bound acquisition fct with AL

[Ef_f, Varf_f] = gp_pred(gp_f, x_f, y_f, x_new);

Ef_f = Ef_f.*std_yf+mean_yf;
Varf_f = Varf_f.*(std_yf^2);

if multipleCons == 0
    
    [Ef_c, Varf_c] = gp_pred(gp_c, x_c, y_c, x_new);
    
else
    
    nCons = size(mean_yc,2);
    
    for icons=1:nCons
        [Ef_c(:,icons), Varf_c(:,icons)] = gp_pred(gp_c{icons}, x_c, y_c(:,icons), x_new);
    end
    
end

Ef_c = Ef_c.*std_yc+mean_yc;
Varf_c = Varf_c.*(std_yc.^2);

if multipleCons == 0
    
    if noMax == 0 % expression with Max in
        
        [Ef_maxTerm, Varf_maxTerm] = ExpectVarMaxTerm(x_new, gp_c, x_c, y_c, ...
            mean_yc, std_yc, 0); %fmin=0
        
        avgCov = approximateCov(x_new, gp_c, x_c, y_c, mean_yc, std_yc, Ns, T);
        avgCov = avgCov';
        
        Ef_AL = Ef_f + lambda * Ef_c + 1/(2*rho) * Ef_maxTerm;
        
        Varf_AL = Varf_f + lambda^2 * Varf_c + ...
            1/(4*rho^2) * Varf_maxTerm + lambda/rho * avgCov;
        
    else % max term dropped
        
        Ef_AL = Ef_f + lambda * Ef_c + 1/(2*rho) * (Varf_c + Ef_c.^2);
        
        Varf_AL = Varf_f + lambda^2 * Varf_c + ...
            1/(2*rho^2) * Varf_c .* (2*Ef_c.^2+Varf_c) + 2*lambda/rho * Ef_c.*Varf_c;
        
    end
    
else
    
    if noMax == 0 % expression with Max in
        
        nCons = size(mean_yc,2);
        
        parfor icons=1:nCons
            [Ef_maxTerm(:,icons), Varf_maxTerm(:,icons)] = ExpectVarMaxTerm(x_new, gp_c{icons}, ...
                x_c, y_c(:,icons), mean_yc(icons), std_yc(icons), 0); %fmin=0
            
            avgCov(:,icons) = approximateCov(x_new, gp_c{icons}, x_c, y_c(:,icons), ...
                mean_yc(icons), std_yc(icons), Ns, T);

        end
        
         
        Ef_AL = Ef_f + sum(Ef_c .* lambda,2) + 1/(2*rho) * sum(Ef_maxTerm,2);
        
        Varf_AL = Varf_f + sum(Varf_c .* (lambda.^2),2) + ...
            1/(4*rho^2) * sum(Varf_maxTerm,2) + sum(lambda./rho .* avgCov,2);
        
    else % max term dropped
        
        Ef_AL = Ef_f + sum(Ef_c .* lambda,2) + 1/(2*rho) * sum(Varf_c + Ef_c.^2,2);
        
        Varf_AL = Varf_f + sum(lambda.^2 .* Varf_c,2) + ...
            1/(2*rho^2) * sum (Varf_c .* (2*Ef_c.^2+Varf_c), 2) + ...
            sum (2*lambda./rho .* Ef_c.*Varf_c,2);
        
    end
    
end

% maximise f(x) true function
% i.e. maximise Ef +  beta .* sqrt(Varf), as Ef stands for f(x), and so
% we maximise Ef and also Varf
%
% minimise f(x) true fct
% i.e. minimise Ef -  beta .* sqrt(Varf), as Ef stands for f(x), and so
% we minimise Ef and also -Varf

if minUCB_idx == 1 % we minimise f(x) true fct
    UCB = Ef_AL -  beta .* sqrt(Varf_AL); % minimise this
else % we maximise f(x) true fct
    UCB = Ef_AL +  beta .* sqrt(Varf_AL); % maximise this
    UCB = -UCB; % minimise this
end

end