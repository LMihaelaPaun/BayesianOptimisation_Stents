function [UCB_HCW,UCB,probSuccess] = ucb_hcw_entropy(x_new, gp, x, gp_class, x_class, ...
    y_class, beta, y, mean_y, std_y, minUCB_idx, tst, alp1, alp2, w, multipleCons)

% Calculate upper confidence bound acquisition fct

[Ef, Varf] = gp_pred(gp, x, y, x_new);

Ef = Ef.*std_y+mean_y;
Varf = Varf.*(std_y^2);
    
% maximise f(x) true function
% i.e. maximise Ef +  beta .* sqrt(Varf), as Ef stands for f(x), and so
% we maximise Ef and also Varf
%
% minimise f(x) true fct
% i.e. minimise Ef -  beta .* sqrt(Varf), as Ef stands for f(x), and so
% we minimise Ef and also -Varf
%
%
if minUCB_idx == 1 % we minimise f(x) true fct
    UCB = Ef -  beta .* sqrt(Varf); % minimise this
else % we maximise f(x) true fct
    UCB = Ef +  beta .* sqrt(Varf); % maximise this
    UCB = -UCB; % minimise this   
end

if multipleCons==0 % one single constraint
    
    [~, ~, lpyt_la, ~, ~] = gp_pred(gp_class, x_class, ...
        y_class, x_new, 'yt', ones(size(x_new,1),1));
    
    probSuccess = exp(lpyt_la);
    
else % multiple constraints
    
    n_xnew = size(x_new,1);
    nCons = size(y_class,2);
    eachProbSuccess = NaN(nCons,n_xnew);
    for icons = 1:nCons
        [~, ~, lpyt_la, ~, ~] = gp_pred(gp_class{icons}, x_class, ...
            y_class(:,icons), x_new, 'yt', ones(n_xnew,1));
        
        eachProbSuccess(icons,:) = exp(lpyt_la);
    end
    
    probSuccess = prod(eachProbSuccess); probSuccess = probSuccess';
    
end

if isnan(probSuccess) % a prediction can occasionally be NaN
    
    UCB_HCW = inf;
    
else
    % hidden (inequality) constraint UCB
    
    if tst == 1
        UCB_HCW = (UCB.^alp1) .* (probSuccess.^alp2);
    elseif tst==2
        entropy = -probSuccess.*log(probSuccess) - (1-probSuccess).*(1-log(probSuccess));
        UCB_HCW = (UCB.^alp1) .* (entropy.^alp2);
    else %tst==3
        entropy = (2*probSuccess.*(1-probSuccess))./(probSuccess - 2*w*probSuccess+w^2);
        UCB_HCW = (UCB.^alp1) .* (entropy.^alp2);
    end
    
end

end