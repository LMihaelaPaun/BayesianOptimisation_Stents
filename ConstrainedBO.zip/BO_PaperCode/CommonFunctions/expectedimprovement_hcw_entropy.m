function [EI_HCW, EI] = expectedimprovement_hcw_entropy(x_new, gp, x, a, invC, fmin, ...
    gp_class, x_class, y_class, mean_y, std_y, tst, alp1, alp2, w, multipleCons)

% Calculate expected improvement acquisition fct with constrained or
% entropy

if ~isempty(x)
    Knx = gp_cov(gp,x_new,x);
    Kn = gp_trvar(gp,x_new);
    Ef = Knx*a; Ef=Ef(1:size(x_new,1));
    invCKnxt = invC*Knx';
    Varf = Kn - sum(Knx.*invCKnxt',2);
    Varf=max(Varf(1:size(x_new,1)),0);
    
    %
    Ef = Ef*std_y+mean_y;
    Varf = Varf*std_y^2;
    fmin=fmin*std_y+mean_y;
    %
    
    % expected improvement
    posvar=find(Varf>0);
    CDFpart = zeros(size(Varf));
    PDFpart = zeros(size(Varf));
    tmp = (fmin - Ef(posvar))./sqrt(Varf(posvar));
    CDFpart(posvar) = normcdf(tmp);
    CDFpart(~posvar) = (fmin - Ef(~posvar))>0;
    PDFpart(posvar) = normpdf(tmp);
    EI =  (fmin - Ef).*CDFpart + sqrt(Varf).*PDFpart; % maximise this when we minimise true fct f(x), i.e. we minimise Ef, hence maximise -Ef, and maximise Varf also
else
    EI = 1;
end

EI = -EI;

if multipleCons==0 % one single constraint
    
    [~, ~, lpyt_la, ~, ~] = gp_pred(gp_class, x_class, ...
        y_class, x_new, 'yt', ones(size(x_new,1),1));
    
    probSuccess = exp(lpyt_la);
    
else % multiple constraints
    
    n_xnew = size(x_new,1);
    nCons = size(y_class,2);
    eachProbSuccess = NaN(nCons,n_xnew);
    for icons = 1:nCons
        [~, ~, lpyt_la, ~, ~] = gp_pred(gp_class{icons}, x_class, ...
            y_class(:,icons), x_new, 'yt', ones(n_xnew,1));
        
        eachProbSuccess(icons,:) = exp(lpyt_la);
    end
    
    probSuccess = prod(eachProbSuccess); probSuccess = probSuccess';
    
end

if isnan(probSuccess) % a prediction can occasionally be NaN
    
    EI_HCW = inf;
    
else
    % hidden (inequality) constraint weighted expected improvement
    if tst == 1
        EI_HCW = (EI.^alp1) .* (probSuccess.^alp2);
    elseif tst==2
        entropy = -probSuccess.*log(probSuccess) - (1-probSuccess).*(1-log(probSuccess));
        EI_HCW = (EI.^alp1) .* (entropy.^alp2);
    else %tst==3
        entropy = (2*probSuccess.*(1-probSuccess))./(probSuccess - 2*w*probSuccess+w^2);
        EI_HCW = (EI.^alp1) .* (entropy.^alp2);
    end
end

end