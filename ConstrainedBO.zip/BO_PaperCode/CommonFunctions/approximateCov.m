function avgCov = approximateCov(theta, gp_c, x_c, y_c, mean_yc, std_yc, Ns, T)
% function that calculates Cov between Y_c and (max(0,Y_c))^2 numerically by MC
% needed for UCB-AL
% called in ucb_hcw_AL

nt = size(theta,1);
CovTerm = NaN(T,nt);
% maxTermMean = NaN(T,nt);
% maxTermVar = NaN(T,nt);

for i=1:nt
    for t = 1:T
        % sample Ns samples from GP post distribution of c
        PostDraws_c = drawGPsamples(theta(i,:), gp_c, x_c, y_c, Ns);
        
        % Scale the posterior draws to original scale
        PostDraws_c = PostDraws_c.*std_yc + mean_yc;
        maxTermPostDraws_c = (max(0, PostDraws_c)).^2;
                
        % compute covariance
        CovMatrix = cov(PostDraws_c,maxTermPostDraws_c);
        CovTerm(t,i) = CovMatrix(1,2);% or CovMatrix(2,1) they're equal

    end
end

% average to get expected covariance

avgCov = mean(CovTerm,1); % should be (nt,1) size

    function PostDraws = drawGPsamples(theta, gp, x, y, Ns)
        % Function that draws Ns samples from a GP posterior distribution
        
        % need the posterior mean and posterior covariance matrix
        postMean = gp_pred(gp, x, y, theta);
        
        s2 = gp.lik.sigma2;
        
        n = size(x,1);
        
        A = gp_trcov(gp, theta); %gp_trvar(gp, theta); % either works
        C = gp_trcov(gp, x) + s2*eye(n, n); % we update the gp and x at every BO iteration, so we need to re-obtain C every time
        B = gp_cov(gp, theta, x);
        %%%% B_t = gp_cov(gp, x, theta); this is simply B'
        
        postCovMat = A - B/C*B' + s2*eye(size(theta,1));
        
        if ~issymmetric(postCovMat)
            postCovMat = (postCovMat+postCovMat')/2; % to make it symmetric
        end
        
        PostDraws = mvnrnd(postMean, postCovMat, Ns);
        
    end

end

