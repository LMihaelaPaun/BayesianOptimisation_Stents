%%%%%%%%%%%%%%%%%
%%%%%% Run Bayesian Optimization on a toy problem %%%%%
%%% Mihaela Paun %%%

clear; close all;

addpath(genpath('/./BO_PaperCode'))

% Add path to GPstuff toolbox
% !!!this path only contains the amplitude truncation below 10^5 in fminscg
GPpath = genpath('/./gpstuff-develop'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path

%% SECTION 1: Run the model for a number of parameter values from a space filling design
th = 0; % threshold value
ObjFct = @(x) -(cos((x(:,1)-0.1).*x(:,2))).^2 - x(:,1) .* sin(3*x(:,1)+x(:,2)); % minimise this, should find x=0;
ConsFct = @(x,t) x(:,1).^2 + x(:,2).^2 - (2.*cos(t)-0.5.*cos(2.*t)-0.25.*cos(3.*t)-0.125.*cos(4.*t)).^2 - (2.*sin(t)).^2; % subject to the constrant that x < th

nd = 2; % no of parameters

nrun = 30;

maxiter = 100; % BO budget (maximum no of function evaluations)

discreteOptim = 0;

multipleCons = 0; % multiple constraints?

for irun=1:nrun
    
    % lower and upper bounds for the drug mass and stent coating
    l = [-2.25,-2.5];
    u = [2.5,1.75];
    
    rng(irun,'twister')
    
    X = lhsdesign(nd*10,nd);
    
    param = l + (u-l) .* X;
    
    t=atan2(param(:,1),param(:,2));
    fct_eval = ObjFct(param);
    C_eval = ConsFct(param,t);
    conSatisf = C_eval<th;
    
    %% SECTION 2: Construct initial GP model out of the simulator callings above
    
    sc = abs(u);
    
    l = l./sc; u = u./sc;
    
    conSatisf = logical(conSatisf);
    
    x_regr = param./sc; y_regr = fct_eval;
    
    x_class = param./sc; y_class = 2.*conSatisf-1;
    
    %%%
    
    mean_y = mean(y_regr);
    std_y = std(y_regr);
    
    % Scale y_regr
    y_regr = (y_regr-mean_y)./std_y; % mean 0 and std 1 of of y
    
    % Build GP models (regression emulator for normalised area above Rs2)
    % and classifier for upper constraint on DC max value
    
    X_r = sobolset(nd+2, 'Skip',2e12,'Leap',0.45e15); % draw 10 values
    n_r = size(X_r, 1);
    
    l_r = [0.5 repmat(0.1,1,nd) 10^(-6)];
    u_r = [1.5 ones(1,nd) 1];
    
    % Initialisations for amplitude, lengthscale and likelihood noise for GP
    % regression
    H_r = [];
    for i=1:nd+2
        H_r = [H_r, l_r(i) + (u_r(i)-l_r(i)) * X_r(:,i)];
    end
    
    % Initialisations for amplitude and lengthscale for GP classification
    X_c = sobolset(nd+1, 'Skip',4e8,'Leap',0.45e15); % draw 21 values
    n_c = size(X_c, 1);
    
    l_c = [0.5 repmat(0.1,1,nd)];
    u_c = [1.5 ones(1,nd)];
    
    H_c = [];
    for i=1:nd+1
        H_c = [H_c, l_c(i) + (u_c(i)-l_c(i)) * X_c(:,i)];
    end
    
    jitterIndex = 1; % 1:small jitter, 2:large jitter
    
    meanf_ind_f=0; meanf_ind_c=2; % quadratic mean
    [gp_regr, nlml_regr, gp_class, nlml_class] = ...
        GPmodel_toy(x_regr, y_regr, x_class, y_class, ...
        H_r(1:8,:), H_c(1,:), meanf_ind_c,meanf_ind_f, jitterIndex);
    
    %% SECTION 3: Carry out BO
    
    i1 = 0; % no of BO iterations -- no of iterations when constraint satisfied
    
    count = 0; % total no of iterations (includes those that progress or not the obj fct)
    
    % Set the options for optimizer of the acquisition function
    
    opts = optimoptions(@fmincon,'Algorithm','sqp');

    globalOptimaY = inf * ones(maxiter,1); % stores all the global optima y (obj fct) points
    globalOptimaX = inf * ones(maxiter,nd); % stores all the global optima x (param) points
    
    globalOptimaYfct_min = inf;
    
    delta = 0.1; % needed for UCB calculation
    
    minUCB_idx = 1; % needed for UCB calculation (minimise fx)
    
    tst = 3; % which test statitic we optimise in ucb_hcw_entropy
    alp1=1; alp2=5; w=2/3; % parameters for the test statistic
    
    while count < maxiter %&& improv>1e-6
        
        count = count + 1;
        
        % Calculate HCW UCB and posterior of the function for visualization purposes
        betaC = 2*log((pi^2*(count+1)^(nd/2+2))/(3*delta));
        
        % optimize acquisition function
        
        fh_af = @(x_new) ucb_hcw_entropy(x_new, gp_regr, x_regr, ...
            gp_class, x_class, y_class, betaC, y_regr, mean_y, std_y, minUCB_idx,...
            tst, alp1, alp2, w, multipleCons);
        
        
        if discreteOptim==1
            Xstar = lhsdesign(10^3,1);
            xstar=l + (u-l) .* Xstar;
            AFstar = fh_af(xstar);
            xstart = xstar(AFstar==min(AFstar));
            
            bestX = xstart;
            
        else
            
            Xo = lhsdesign(1,nd);
            xstart = NaN(size(Xo,1),nd);
            for j=1:nd
                xstart(:,j) = l(j) + (u(j)-l(j)) * Xo(:,j); % starting values for the BO algorithm
            end
            
            problem = createOptimProblem('fmincon','objective',...
                fh_af,'x0',xstart,'lb',l,'ub',u,'options',opts);
            
            gs = GlobalSearch('NumTrialPoints',10^3);
            [bestX,bestAF] = run(gs,problem);
            
        end
        
        bX = bestX.*sc;
        
        bestObjF= ObjFct(bX);
        
        t=atan2(bX(:,1),bX(:,2));
        
        bestCst = ConsFct(bX,t)-th;
        conS = bestCst<10^(-4);
        
        if conS==1 && bestObjF < globalOptimaYfct_min
            % the minimum so far
            globalOptimaYfct_min = bestObjF;
            globalOptimaXfct_min = bX;
        end
        
        %if conS == 1 % successful simulation - THIS CORRECT?? or always add???
        % put new sample point to the list of evaluation points for norm areaRs2
        x_regr(end+1,:) = bestX;
        y_regr = y_regr.*std_y+mean_y; % un-scale
        y_regr(end+1) = bestObjF; % on original scale
        mean_y = mean(y_regr); std_y = std(y_regr); % new mean and std
        
        y_regr = (y_regr-mean_y)./std_y; % scale back
        
        if conS == 1 % successful simulation
            
            globalOptimaY(count) = bestObjF; % y on original scale it's okay
            globalOptimaX(count,:) = bX; % x on original scale
            
            disp('successful')
            
            i1 = i1 + 1;
            
            
        else
            disp('unsuccessful')
            
            i1 = i1;
            
        end
        
        % put new sample point to the list of evaluation classification points
        x_class(end+1,:) = bestX; y_class(end+1) = 2.*conS-1;
        
        try
            gp_regr = gp_optim(gp_regr,x_regr,y_regr);
            gp_class = gp_optim(gp_class,x_class,y_class);
        catch
            [gp_regr, nlml_regr, gp_class, nlml_class] = ...
                GPmodel_toy(x_regr, y_regr, x_class, y_class, H_r, ...
                H_c(1,:), meanf_ind_c,meanf_ind_f, jitterIndex);
        end
        
        if discreteOptim==1
            save(sprintf('/./PaperResults/ToyProblems/Example2D_oneCons/UCB_entropy_discreteOptim_run %d.mat', irun))
            
        else
            save(sprintf('/./PaperResults/ToyProblems/Example2D_oneCons/UCB_entropy_run %d.mat', irun))
        end
    end

end

exit;